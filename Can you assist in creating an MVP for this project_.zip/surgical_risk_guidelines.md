# Surgical Risk Assessment Guidelines

## Preoperative Risk Stratification

### ASA Physical Status Classification System

**ASA Class I (Normal healthy patient)**
- No organic, physiologic, or psychiatric disturbance
- Excludes the very young and very old
- Healthy with good exercise tolerance
- Non-smoking
- Minimal alcohol use

**ASA Class II (Mild systemic disease)**
- Mild diseases only without substantive functional limitations
- Current smoker, social alcohol drinker, pregnancy, obesity (BMI 30-40), well-controlled diabetes or hypertension
- Mild lung disease

**ASA Class III (Severe systemic disease)**
- Substantive functional limitations; one or more moderate to severe diseases
- Poorly controlled diabetes or hypertension, COPD, morbid obesity (BMI ≥40), active hepatitis
- Alcohol dependence or abuse, implanted pacemaker, moderate reduction of ejection fraction
- ESRD undergoing regularly scheduled dialysis, premature infant PCA < 60 weeks
- History (>3 months) of MI, CVA, TIA, or CAD/stents

**ASA Class IV (Severe systemic disease that is a constant threat to life)**
- Recent (<3 months) MI, CVA, TIA, or CAD/stents, ongoing cardiac ischemia or severe valve dysfunction
- Severe reduction of ejection fraction, sepsis, DIC, ARD or ESRD not undergoing regularly scheduled dialysis

**ASA Class V (Moribund patient who is not expected to survive without the operation)**
- Ruptured abdominal/thoracic aneurysm, massive trauma, intracranial bleed with mass effect
- Ischemic bowel in the face of significant cardiac pathology or multiple organ/system dysfunction

## Cardiac Risk Assessment

### Revised Cardiac Risk Index (RCRI)
Risk factors (1 point each):
1. High-risk surgery (intrathoracic, intraperitoneal, or suprainguinal vascular)
2. History of ischemic heart disease
3. History of congestive heart failure
4. History of cerebrovascular disease
5. Diabetes mellitus requiring insulin therapy
6. Preoperative serum creatinine >2.0 mg/dL

**Risk Stratification:**
- 0 points: Very low risk (0.4% cardiac events)
- 1 point: Low risk (0.9% cardiac events)
- 2 points: Intermediate risk (6.6% cardiac events)
- ≥3 points: High risk (>11% cardiac events)

### Perioperative Beta-Blocker Guidelines
**Indications for perioperative beta-blockers:**
- Patients already on beta-blockers should continue
- Consider for patients with known CAD or multiple cardiac risk factors undergoing vascular surgery
- Avoid in patients with contraindications (severe asthma, heart block, severe heart failure)

## Pulmonary Risk Assessment

### Risk Factors for Postoperative Pulmonary Complications
**Patient-related factors:**
- Age >70 years
- ASA class ≥2
- Functionally dependent
- COPD
- Congestive heart failure
- Cigarette smoking within 8 weeks
- Obstructive sleep apnea
- Pulmonary hypertension

**Procedure-related factors:**
- Surgical site (thoracic > upper abdominal > lower abdominal)
- Duration >3 hours
- Emergency surgery
- General anesthesia

### Preoperative Pulmonary Function Testing
**Indications:**
- Lung resection surgery
- Upper abdominal or thoracic surgery in patients with unexplained dyspnea or exercise intolerance
- COPD or asthma patients with recent exacerbation

## Renal Risk Assessment

### Risk Factors for Acute Kidney Injury
**Preoperative factors:**
- Chronic kidney disease (baseline creatinine >1.5 mg/dL)
- Diabetes mellitus
- Hypertension
- Age >65 years
- Congestive heart failure
- Liver disease
- Emergency surgery

**Intraoperative factors:**
- Hypotension
- Use of nephrotoxic agents
- Blood loss requiring transfusion

### Preoperative Creatinine Interpretation
- Normal: <1.2 mg/dL
- Mild elevation: 1.2-2.0 mg/dL
- Moderate elevation: 2.0-3.0 mg/dL
- Severe elevation: >3.0 mg/dL

## Bleeding Risk Assessment

### Risk Factors for Perioperative Bleeding
**Patient factors:**
- History of bleeding disorders
- Liver disease
- Renal failure
- Thrombocytopenia (<100,000/μL)
- Use of anticoagulants or antiplatelet agents

**Laboratory markers:**
- INR >1.5
- PTT >40 seconds
- Platelet count <100,000/μL

### Anticoagulation Management
**Warfarin:**
- Stop 5 days before surgery
- Bridge with heparin if high thrombotic risk
- Resume 12-24 hours post-surgery if adequate hemostasis

**Novel oral anticoagulants (NOACs):**
- Stop 1-2 days before low bleeding risk procedures
- Stop 2-3 days before high bleeding risk procedures

## Age-Related Considerations

### Geriatric Surgery Risk Factors
**Age >80 years:**
- Increased risk of delirium
- Slower recovery
- Higher complication rates
- Consider frailty assessment

**Frailty indicators:**
- Unintentional weight loss
- Exhaustion
- Weakness (grip strength)
- Slow walking speed
- Low physical activity

## Emergency Surgery Considerations

### Additional Risk Factors
- Inadequate preoperative optimization
- Hemodynamic instability
- Acute illness severity
- Limited time for risk assessment
- Higher complication rates across all categories

### Risk Mitigation Strategies
- Rapid assessment protocols
- Early ICU involvement for high-risk patients
- Aggressive perioperative monitoring
- Consider less invasive alternatives when possible

## Obesity and Metabolic Considerations

### BMI Categories and Surgical Risk
- Normal (18.5-24.9): Baseline risk
- Overweight (25-29.9): Slightly increased risk
- Obese Class I (30-34.9): Moderately increased risk
- Obese Class II (35-39.9): Significantly increased risk
- Obese Class III (≥40): Very high risk

### Obesity-Related Complications
- Difficult airway management
- Increased risk of DVT/PE
- Wound healing complications
- Sleep apnea
- Diabetes and metabolic syndrome

## Laboratory Value Interpretations

### Hemoglobin Thresholds
- Normal: >12 g/dL (women), >13.5 g/dL (men)
- Mild anemia: 10-12 g/dL (women), 10-13.5 g/dL (men)
- Moderate anemia: 8-10 g/dL
- Severe anemia: <8 g/dL

### Electrolyte Considerations
**Sodium:**
- Normal: 135-145 mEq/L
- Hyponatremia: <135 mEq/L (increased risk of complications)
- Hypernatremia: >145 mEq/L

**Potassium:**
- Normal: 3.5-5.0 mEq/L
- Hypokalemia: <3.5 mEq/L (arrhythmia risk)
- Hyperkalemia: >5.0 mEq/L (arrhythmia risk)

## Risk Communication and Informed Consent

### Risk Categories for Patient Communication
- Very Low Risk: <1% major complications
- Low Risk: 1-5% major complications
- Intermediate Risk: 5-15% major complications
- High Risk: 15-25% major complications
- Very High Risk: >25% major complications

### Documentation Requirements
- ASA physical status
- Major risk factors identified
- Risk mitigation strategies employed
- Patient understanding of risks documented

