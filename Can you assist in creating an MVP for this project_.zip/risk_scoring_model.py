"""
XGBoost Risk Scoring Model for Surgical Risk Assessment
Implements calibrated risk scoring with 0-100 scale as described in design document.
"""

import json
import numpy as np
import pandas as pd
import pickle
from typing import Dict, List, Any, Tuple
import sys
import os

# Add data directory to path
sys.path.append('/home/ubuntu/surgical-risk-mvp/data')

import xgboost as xgb
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.metrics import (
    roc_auc_score, roc_curve, precision_recall_curve, 
    classification_report, confusion_matrix, brier_score_loss
)
from sklearn.isotonic import IsotonicRegression
import matplotlib.pyplot as plt

from feature_engineering import SurgicalRiskFeatureEngineer

class SurgicalRiskModel:
    def __init__(self):
        """Initialize the surgical risk scoring model."""
        self.model = None
        self.calibrator = None
        self.feature_engineer = None
        self.is_trained = False
        self.feature_importance = None
        self.model_metrics = {}
        
        # Risk band thresholds (as per design document)
        self.risk_bands = {
            'LOW': (0, 20),
            'MODERATE': (21, 40),
            'ELEVATED': (41, 60),
            'HIGH': (61, 80),
            'VERY HIGH': (81, 100)
        }

    def get_risk_band(self, risk_score: int) -> str:
        """Convert risk score to risk band."""
        for band, (low, high) in self.risk_bands.items():
            if low <= risk_score <= high:
                return band
        return 'UNKNOWN'

    def load_training_data(self) -> Tuple[pd.DataFrame, np.ndarray, pd.DataFrame, np.ndarray]:
        """Load and prepare training and validation data."""
        print("Loading training data...")
        
        # Load training patients
        with open('/home/ubuntu/surgical-risk-mvp/data/synthetic/training_patients.json', 'r') as f:
            training_patients = json.load(f)
        
        # Load validation patients
        with open('/home/ubuntu/surgical-risk-mvp/data/synthetic/validation_patients.json', 'r') as f:
            validation_patients = json.load(f)
        
        # Initialize feature engineer
        self.feature_engineer = SurgicalRiskFeatureEngineer()
        
        # Create feature matrices
        X_train, y_train = self.feature_engineer.fit_transform(training_patients)
        X_val, y_val = self.feature_engineer.create_feature_matrix(validation_patients)
        X_val = self.feature_engineer.transform_features(X_val)
        
        print(f"Training set: {X_train.shape[0]} patients, {X_train.shape[1]} features")
        print(f"Validation set: {X_val.shape[0]} patients, {X_val.shape[1]} features")
        print(f"Training positive rate: {y_train.mean():.3f}")
        print(f"Validation positive rate: {y_val.mean():.3f}")
        
        return X_train, y_train, X_val, y_val

    def train_model(self, X_train: pd.DataFrame, y_train: np.ndarray, 
                   X_val: pd.DataFrame, y_val: np.ndarray) -> None:
        """Train the XGBoost model with hyperparameter tuning."""
        print("Training XGBoost model...")
        
        # Define parameter grid for hyperparameter tuning
        param_grid = {
            'n_estimators': [100, 200, 300],
            'max_depth': [3, 4, 5, 6],
            'learning_rate': [0.01, 0.1, 0.2],
            'subsample': [0.8, 0.9, 1.0],
            'colsample_bytree': [0.8, 0.9, 1.0]
        }
        
        # Initialize base model
        base_model = xgb.XGBClassifier(
            objective='binary:logistic',
            random_state=42,
            n_jobs=-1,
            eval_metric='auc'
        )
        
        # Perform grid search with cross-validation
        print("Performing hyperparameter tuning...")
        grid_search = GridSearchCV(
            base_model,
            param_grid,
            cv=5,
            scoring='roc_auc',
            n_jobs=-1,
            verbose=1
        )
        
        grid_search.fit(X_train, y_train)
        
        # Get best model
        self.model = grid_search.best_estimator_
        
        print(f"Best parameters: {grid_search.best_params_}")
        print(f"Best CV AUC: {grid_search.best_score_:.4f}")
        
        # Evaluate on validation set
        val_pred_proba = self.model.predict_proba(X_val)[:, 1]
        val_auc = roc_auc_score(y_val, val_pred_proba)
        print(f"Validation AUC: {val_auc:.4f}")
        
        # Store metrics
        self.model_metrics['best_cv_auc'] = grid_search.best_score_
        self.model_metrics['validation_auc'] = val_auc
        self.model_metrics['best_params'] = grid_search.best_params_

    def calibrate_model(self, X_train: pd.DataFrame, y_train: np.ndarray,
                       X_val: pd.DataFrame, y_val: np.ndarray) -> None:
        """Calibrate the model using isotonic regression."""
        print("Calibrating model probabilities...")
        
        # Get uncalibrated predictions
        train_pred_proba = self.model.predict_proba(X_train)[:, 1]
        val_pred_proba = self.model.predict_proba(X_val)[:, 1]
        
        # Fit isotonic regression calibrator
        self.calibrator = IsotonicRegression(out_of_bounds='clip')
        self.calibrator.fit(train_pred_proba, y_train)
        
        # Get calibrated predictions
        train_calibrated = self.calibrator.transform(train_pred_proba)
        val_calibrated = self.calibrator.transform(val_pred_proba)
        
        # Evaluate calibration
        train_brier_before = brier_score_loss(y_train, train_pred_proba)
        train_brier_after = brier_score_loss(y_train, train_calibrated)
        val_brier_before = brier_score_loss(y_val, val_pred_proba)
        val_brier_after = brier_score_loss(y_val, val_calibrated)
        
        print(f"Training Brier Score - Before: {train_brier_before:.4f}, After: {train_brier_after:.4f}")
        print(f"Validation Brier Score - Before: {val_brier_before:.4f}, After: {val_brier_after:.4f}")
        
        # Store calibration metrics
        self.model_metrics['train_brier_before'] = train_brier_before
        self.model_metrics['train_brier_after'] = train_brier_after
        self.model_metrics['val_brier_before'] = val_brier_before
        self.model_metrics['val_brier_after'] = val_brier_after

    def analyze_feature_importance(self) -> None:
        """Analyze and store feature importance."""
        print("Analyzing feature importance...")
        
        # Get feature importance from XGBoost
        importance_scores = self.model.feature_importances_
        feature_names = self.feature_engineer.get_feature_importance_names()
        
        # Create importance DataFrame
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': importance_scores
        }).sort_values('importance', ascending=False)
        
        self.feature_importance = importance_df
        
        print("Top 10 most important features:")
        print(importance_df.head(10))

    def predict_risk_score(self, patient_data: Dict[str, Any]) -> Dict[str, Any]:
        """Predict risk score for a single patient."""
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")
        
        # Transform patient data to features
        X = self.feature_engineer.transform_single_patient(patient_data)
        
        # Get model prediction
        pred_proba = self.model.predict_proba(X)[0, 1]
        
        # Apply calibration
        if self.calibrator is not None:
            calibrated_proba = self.calibrator.transform([pred_proba])[0]
        else:
            calibrated_proba = pred_proba
        
        # Convert to 0-100 scale
        risk_score = int(round(calibrated_proba * 100))
        risk_score = max(0, min(100, risk_score))  # Ensure bounds
        
        # Get risk band
        risk_band = self.get_risk_band(risk_score)
        
        return {
            'risk_score': risk_score,
            'risk_band': risk_band,
            'risk_probability': calibrated_proba,
            'uncalibrated_probability': pred_proba
        }

    def evaluate_model(self, X_val: pd.DataFrame, y_val: np.ndarray) -> Dict[str, Any]:
        """Comprehensive model evaluation."""
        print("Evaluating model performance...")
        
        # Get predictions
        val_pred_proba = self.model.predict_proba(X_val)[:, 1]
        if self.calibrator is not None:
            val_calibrated = self.calibrator.transform(val_pred_proba)
        else:
            val_calibrated = val_pred_proba
        
        # Convert to risk scores
        val_risk_scores = np.round(val_calibrated * 100).astype(int)
        val_risk_scores = np.clip(val_risk_scores, 0, 100)
        
        # Calculate metrics
        auc = roc_auc_score(y_val, val_calibrated)
        brier = brier_score_loss(y_val, val_calibrated)
        
        # Risk band accuracy
        risk_band_predictions = [self.get_risk_band(score) for score in val_risk_scores]
        
        # Calculate calibration curve
        fraction_of_positives, mean_predicted_value = calibration_curve(
            y_val, val_calibrated, n_bins=10
        )
        
        evaluation = {
            'auc': auc,
            'brier_score': brier,
            'mean_risk_score': val_risk_scores.mean(),
            'risk_score_std': val_risk_scores.std(),
            'calibration_slope': np.corrcoef(mean_predicted_value, fraction_of_positives)[0, 1],
            'fraction_of_positives': fraction_of_positives.tolist(),
            'mean_predicted_value': mean_predicted_value.tolist()
        }
        
        print(f"Final Model Performance:")
        print(f"  AUC: {auc:.4f}")
        print(f"  Brier Score: {brier:.4f}")
        print(f"  Mean Risk Score: {val_risk_scores.mean():.1f}")
        print(f"  Risk Score Std: {val_risk_scores.std():.1f}")
        
        return evaluation

    def train_complete_pipeline(self) -> None:
        """Train the complete model pipeline."""
        print("Starting complete model training pipeline...")
        
        # Load data
        X_train, y_train, X_val, y_val = self.load_training_data()
        
        # Train model
        self.train_model(X_train, y_train, X_val, y_val)
        
        # Calibrate model
        self.calibrate_model(X_train, y_train, X_val, y_val)
        
        # Analyze feature importance
        self.analyze_feature_importance()
        
        # Evaluate model
        evaluation = self.evaluate_model(X_val, y_val)
        self.model_metrics.update(evaluation)
        
        self.is_trained = True
        print("Model training completed successfully!")

    def save_model(self, filepath: str) -> None:
        """Save the complete trained model."""
        if not self.is_trained:
            raise ValueError("Model must be trained before saving")
        
        model_data = {
            'model': self.model,
            'calibrator': self.calibrator,
            'feature_engineer': self.feature_engineer,
            'feature_importance': self.feature_importance,
            'model_metrics': self.model_metrics,
            'risk_bands': self.risk_bands,
            'is_trained': self.is_trained
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(model_data, f)
        
        print(f"Model saved to {filepath}")

    def load_model(self, filepath: str) -> None:
        """Load a trained model."""
        with open(filepath, 'rb') as f:
            model_data = pickle.load(f)
        
        self.model = model_data['model']
        self.calibrator = model_data['calibrator']
        self.feature_engineer = model_data['feature_engineer']
        self.feature_importance = model_data['feature_importance']
        self.model_metrics = model_data['model_metrics']
        self.risk_bands = model_data['risk_bands']
        self.is_trained = model_data['is_trained']
        
        print(f"Model loaded from {filepath}")

    def create_model_report(self) -> str:
        """Create a comprehensive model report."""
        if not self.is_trained:
            return "Model not trained yet."
        
        report = []
        report.append("# Surgical Risk Assessment Model Report")
        report.append("")
        report.append("## Model Performance Metrics")
        report.append(f"- **Validation AUC**: {self.model_metrics['validation_auc']:.4f}")
        report.append(f"- **Brier Score**: {self.model_metrics['brier_score']:.4f}")
        report.append(f"- **Mean Risk Score**: {self.model_metrics['mean_risk_score']:.1f}")
        report.append("")
        
        report.append("## Model Configuration")
        report.append(f"- **Algorithm**: XGBoost with Isotonic Calibration")
        report.append(f"- **Features**: {len(self.feature_engineer.feature_columns)}")
        report.append(f"- **Best Parameters**: {self.model_metrics['best_params']}")
        report.append("")
        
        report.append("## Top 10 Most Important Features")
        for i, row in self.feature_importance.head(10).iterrows():
            report.append(f"{i+1}. {row['feature']}: {row['importance']:.4f}")
        report.append("")
        
        report.append("## Risk Band Definitions")
        for band, (low, high) in self.risk_bands.items():
            report.append(f"- **{band}**: {low}-{high}")
        
        return "\n".join(report)

def test_model_prediction():
    """Test the model with a sample patient."""
    print("\nTesting model prediction with sample patient...")
    
    # Load a test patient
    with open('/home/ubuntu/surgical-risk-mvp/data/synthetic/test_patients.json', 'r') as f:
        test_patients = json.load(f)
    
    # Load trained model
    model = SurgicalRiskModel()
    model.load_model('/home/ubuntu/surgical-risk-mvp/models/ml_models/surgical_risk_model.pkl')
    
    # Test prediction
    test_patient = test_patients[0]
    prediction = model.predict_risk_score(test_patient)
    
    print(f"Sample Patient Prediction:")
    print(f"  Risk Score: {prediction['risk_score']}")
    print(f"  Risk Band: {prediction['risk_band']}")
    print(f"  Risk Probability: {prediction['risk_probability']:.3f}")
    print(f"  True Outcome: {test_patient['outcome_30day_complication']}")
    print(f"  True Risk Score: {test_patient['true_risk_score']}")

if __name__ == "__main__":
    # Create models directory
    os.makedirs('/home/ubuntu/surgical-risk-mvp/models/ml_models', exist_ok=True)
    
    # Train the model
    model = SurgicalRiskModel()
    model.train_complete_pipeline()
    
    # Save the model
    model.save_model('/home/ubuntu/surgical-risk-mvp/models/ml_models/surgical_risk_model.pkl')
    
    # Create and save model report
    report = model.create_model_report()
    with open('/home/ubuntu/surgical-risk-mvp/models/ml_models/model_report.md', 'w') as f:
        f.write(report)
    
    print("\nModel training and saving completed!")
    
    # Test prediction
    test_model_prediction()

