"""
Risk Assessment API Routes for Surgical Risk Assessment Platform
"""

import os
import sys
import json
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin

# Add project paths
project_root = '/home/ubuntu/surgical-risk-mvp'
sys.path.append(project_root)
sys.path.append(os.path.join(project_root, 'models'))
sys.path.append(os.path.join(project_root, 'vector_db'))
sys.path.append(os.path.join(project_root, 'data'))

from models.risk_scoring_model import SurgicalRiskModel
from vector_db.simple_rag import SurgicalRiskRAGSimple

# Initialize blueprint
risk_bp = Blueprint('risk_assessment', __name__)

# Global variables for loaded models
risk_model = None
rag_system = None

def initialize_models():
    """Initialize the ML model and RAG system."""
    global risk_model, rag_system
    
    try:
        # Load ML model
        risk_model = SurgicalRiskModel()
        model_path = os.path.join(project_root, 'models/ml_models/surgical_risk_model.pkl')
        risk_model.load_model(model_path)
        print("ML model loaded successfully")
        
        # Load RAG system
        rag_system = SurgicalRiskRAGSimple()
        rag_system.load_medical_guidelines()
        print("RAG system loaded successfully")
        
        return True
    except Exception as e:
        print(f"Error initializing models: {e}")
        return False

@risk_bp.route('/health', methods=['GET'])
@cross_origin()
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'service': 'Surgical Risk Assessment API',
        'models_loaded': risk_model is not None and rag_system is not None
    })

@risk_bp.route('/assess-risk', methods=['POST'])
@cross_origin()
def assess_risk():
    """Main risk assessment endpoint."""
    try:
        # Get patient data from request
        patient_data = request.get_json()
        
        if not patient_data:
            return jsonify({'error': 'No patient data provided'}), 400
        
        # Validate required fields
        required_fields = ['age', 'sex', 'bmi']
        for field in required_fields:
            if field not in patient_data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Initialize models if not already loaded
        if risk_model is None or rag_system is None:
            if not initialize_models():
                return jsonify({'error': 'Failed to initialize models'}), 500
        
        # Generate risk prediction
        risk_prediction = risk_model.predict_risk_score(patient_data)
        
        # Generate explanation using RAG
        explanation_result = rag_system.generate_risk_explanation(patient_data, risk_prediction)
        
        # Combine results
        response = {
            'patient_id': patient_data.get('patient_id', 'unknown'),
            'risk_assessment': {
                'risk_score': risk_prediction['risk_score'],
                'risk_band': risk_prediction['risk_band'],
                'risk_probability': round(risk_prediction['risk_probability'], 3)
            },
            'explanations': explanation_result['explanation'],
            'guidelines_used': len(explanation_result['retrieved_guidelines']),
            'timestamp': patient_data.get('created_at', 'unknown')
        }
        
        return jsonify(response)
        
    except Exception as e:
        print(f"Error in risk assessment: {e}")
        return jsonify({'error': f'Risk assessment failed: {str(e)}'}), 500

@risk_bp.route('/patient-template', methods=['GET'])
@cross_origin()
def get_patient_template():
    """Get a template for patient data structure."""
    template = {
        'patient_id': 'PAT_123456',
        'age': 65,
        'sex': 'M',  # 'M' or 'F'
        'height_cm': 175.0,
        'weight_kg': 80.0,
        'bmi': 26.1,
        'labs': {
            'creatinine': 1.0,  # mg/dL
            'hemoglobin': 13.5,  # g/dL
            'sodium': 140,  # mEq/L
            'potassium': 4.0,  # mEq/L
            'alt': 25,  # U/L
            'inr': 1.1  # ratio
        },
        'vitals': {
            'sbp': 130,  # mmHg
            'dbp': 80,  # mmHg
            'heart_rate': 75,  # bpm
            'spo2': 98,  # %
            'temperature': 98.6  # F
        },
        'surgical_details': {
            'procedure_name': 'Cholecystectomy',
            'cpt_invasiveness_tier': 2,  # 1-5
            'asa_class': 2,  # 1-5
            'procedure_duration_min': 120,
            'emergency_case': False
        },
        'medical_history': {
            'conditions': ['Hypertension', 'Diabetes mellitus type 2'],
            'medications': ['Lisinopril', 'Metformin'],
            'allergies': ['Penicillin']
        }
    }
    
    return jsonify({
        'template': template,
        'description': 'Template for patient data structure',
        'required_fields': ['age', 'sex', 'bmi', 'surgical_details', 'labs', 'vitals'],
        'optional_fields': ['medical_history', 'patient_id']
    })

@risk_bp.route('/risk-bands', methods=['GET'])
@cross_origin()
def get_risk_bands():
    """Get risk band definitions."""
    risk_bands = {
        'LOW': {
            'range': '0-20',
            'description': 'Low surgical risk with routine perioperative care',
            'color': '#22c55e'  # green
        },
        'MODERATE': {
            'range': '21-40',
            'description': 'Moderate surgical risk with standard perioperative management',
            'color': '#3b82f6'  # blue
        },
        'ELEVATED': {
            'range': '41-60',
            'description': 'Elevated surgical risk requiring enhanced monitoring',
            'color': '#f59e0b'  # amber
        },
        'HIGH': {
            'range': '61-80',
            'description': 'High surgical risk requiring intensive perioperative care',
            'color': '#ef4444'  # red
        },
        'VERY HIGH': {
            'range': '81-100',
            'description': 'Very high surgical risk requiring specialized management',
            'color': '#7c2d12'  # dark red
        }
    }
    
    return jsonify(risk_bands)

@risk_bp.route('/model-info', methods=['GET'])
@cross_origin()
def get_model_info():
    """Get information about the ML model."""
    if risk_model is None:
        if not initialize_models():
            return jsonify({'error': 'Failed to initialize models'}), 500
    
    try:
        model_info = {
            'algorithm': 'XGBoost with Isotonic Calibration',
            'features': len(risk_model.feature_engineer.feature_columns) if risk_model.feature_engineer else 'Unknown',
            'performance': risk_model.model_metrics if hasattr(risk_model, 'model_metrics') else {},
            'version': '1.0',
            'training_date': '2025-01-08',
            'description': 'Surgical risk assessment model trained on synthetic medical data'
        }
        
        return jsonify(model_info)
        
    except Exception as e:
        return jsonify({'error': f'Failed to get model info: {str(e)}'}), 500

@risk_bp.route('/demo-patients', methods=['GET'])
@cross_origin()
def get_demo_patients():
    """Get demo patients for testing."""
    try:
        # Load some test patients
        test_patients_path = os.path.join(project_root, 'data/synthetic/test_patients.json')
        
        if os.path.exists(test_patients_path):
            with open(test_patients_path, 'r') as f:
                test_patients = json.load(f)
            
            # Return first 5 patients as demos
            demo_patients = test_patients[:5]
            
            # Add simplified versions for frontend
            simplified_demos = []
            for patient in demo_patients:
                simplified = {
                    'patient_id': patient['patient_id'],
                    'age': patient['age'],
                    'sex': patient['sex'],
                    'bmi': patient['bmi'],
                    'procedure': patient['surgical_details']['procedure_name'],
                    'asa_class': patient['surgical_details']['asa_class'],
                    'true_risk_score': patient['true_risk_score'],
                    'full_data': patient
                }
                simplified_demos.append(simplified)
            
            return jsonify({
                'demo_patients': simplified_demos,
                'count': len(simplified_demos)
            })
        else:
            return jsonify({'error': 'Demo patients not found'}), 404
            
    except Exception as e:
        return jsonify({'error': f'Failed to load demo patients: {str(e)}'}), 500

@risk_bp.route('/feedback', methods=['POST'])
@cross_origin()
def submit_feedback():
    """Submit feedback on risk assessment."""
    try:
        feedback_data = request.get_json()
        
        if not feedback_data:
            return jsonify({'error': 'No feedback data provided'}), 400
        
        # Validate feedback structure
        required_fields = ['patient_id', 'risk_score', 'feedback_type']
        for field in required_fields:
            if field not in feedback_data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # In a real system, this would be stored in a database
        # For MVP, we'll just log it
        print(f"Feedback received: {feedback_data}")
        
        # Simulate feedback storage
        feedback_response = {
            'feedback_id': f"FB_{feedback_data['patient_id']}_{len(str(feedback_data))}",
            'status': 'received',
            'message': 'Feedback submitted successfully',
            'timestamp': feedback_data.get('timestamp', 'unknown')
        }
        
        return jsonify(feedback_response)
        
    except Exception as e:
        return jsonify({'error': f'Failed to submit feedback: {str(e)}'}), 500

# Initialize models when module is imported
print("Initializing surgical risk assessment models...")
initialize_models()

