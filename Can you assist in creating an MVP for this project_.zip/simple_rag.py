"""
Simplified RAG System for Surgical Risk Assessment MVP
Uses local text matching and rule-based retrieval instead of external APIs.
"""

import os
import json
import pickle
import re
from typing import List, Dict, Any, Tuple
from collections import defaultdict
import math

class SimpleRAGSystem:
    def __init__(self):
        """Initialize the simplified RAG system."""
        self.documents = []
        self.chunks = []
        self.keyword_index = defaultdict(list)
        
        # Medical keywords for risk assessment
        self.risk_keywords = {
            'cardiac': ['cardiac', 'heart', 'coronary', 'myocardial', 'infarction', 'failure', 'arrhythmia'],
            'pulmonary': ['pulmonary', 'lung', 'respiratory', 'copd', 'asthma', 'pneumonia'],
            'renal': ['renal', 'kidney', 'creatinine', 'dialysis', 'nephropathy'],
            'diabetes': ['diabetes', 'diabetic', 'glucose', 'insulin', 'hyperglycemia'],
            'obesity': ['obesity', 'obese', 'bmi', 'weight', 'morbid'],
            'age': ['age', 'elderly', 'geriatric', 'old'],
            'asa': ['asa', 'physical', 'status', 'classification'],
            'emergency': ['emergency', 'urgent', 'emergent'],
            'bleeding': ['bleeding', 'hemorrhage', 'coagulation', 'anticoagulant', 'warfarin'],
            'anesthesia': ['anesthesia', 'anesthetic', 'airway', 'intubation']
        }

    def load_guidelines(self, filepath: str) -> None:
        """Load medical guidelines from file."""
        with open(filepath, 'r') as f:
            content = f.read()
        
        self.documents = [{
            'source': 'Surgical Risk Assessment Guidelines',
            'content': content
        }]
        
        # Create chunks and build index
        self._create_chunks()
        self._build_keyword_index()
        
        print(f"Loaded guidelines with {len(self.chunks)} chunks")

    def _create_chunks(self) -> None:
        """Create text chunks from documents."""
        self.chunks = []
        
        for doc in self.documents:
            content = doc['content']
            
            # Split by sections (headers)
            sections = re.split(r'\n#+\s+', content)
            
            for i, section in enumerate(sections):
                if len(section.strip()) < 50:  # Skip very short sections
                    continue
                
                # Further split long sections by paragraphs
                paragraphs = section.split('\n\n')
                current_chunk = ""
                
                for paragraph in paragraphs:
                    if len(current_chunk + paragraph) > 800:  # Max chunk size
                        if current_chunk:
                            self.chunks.append({
                                'text': current_chunk.strip(),
                                'source': doc['source'],
                                'chunk_id': len(self.chunks),
                                'section_id': i
                            })
                            current_chunk = paragraph
                        else:
                            # Single paragraph is too long, add it anyway
                            self.chunks.append({
                                'text': paragraph.strip(),
                                'source': doc['source'],
                                'chunk_id': len(self.chunks),
                                'section_id': i
                            })
                            current_chunk = ""
                    else:
                        current_chunk += "\n\n" + paragraph if current_chunk else paragraph
                
                # Add remaining content
                if current_chunk.strip():
                    self.chunks.append({
                        'text': current_chunk.strip(),
                        'source': doc['source'],
                        'chunk_id': len(self.chunks),
                        'section_id': i
                    })

    def _build_keyword_index(self) -> None:
        """Build keyword index for fast retrieval."""
        self.keyword_index = defaultdict(list)
        
        for chunk_idx, chunk in enumerate(self.chunks):
            text_lower = chunk['text'].lower()
            
            # Index by medical keywords
            for category, keywords in self.risk_keywords.items():
                for keyword in keywords:
                    if keyword in text_lower:
                        self.keyword_index[keyword].append(chunk_idx)
            
            # Index by individual words
            words = re.findall(r'\b\w+\b', text_lower)
            for word in words:
                if len(word) > 3:  # Skip very short words
                    self.keyword_index[word].append(chunk_idx)

    def _calculate_relevance_score(self, chunk: Dict[str, Any], query_terms: List[str]) -> float:
        """Calculate relevance score for a chunk given query terms."""
        text_lower = chunk['text'].lower()
        score = 0.0
        
        # Count exact matches
        for term in query_terms:
            term_lower = term.lower()
            count = text_lower.count(term_lower)
            score += count * 2.0  # Exact matches get higher weight
        
        # Count related keyword matches
        for term in query_terms:
            term_lower = term.lower()
            for category, keywords in self.risk_keywords.items():
                if term_lower in keywords:
                    # Give bonus for related keywords in same category
                    for keyword in keywords:
                        if keyword != term_lower and keyword in text_lower:
                            score += 0.5
        
        # Normalize by chunk length
        chunk_length = len(chunk['text'].split())
        if chunk_length > 0:
            score = score / math.log(chunk_length + 1)
        
        return score

    def retrieve_relevant_chunks(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Retrieve relevant chunks for a query."""
        if not self.chunks:
            return []
        
        # Extract query terms
        query_terms = re.findall(r'\b\w+\b', query.lower())
        query_terms = [term for term in query_terms if len(term) > 2]
        
        # Find candidate chunks
        candidate_indices = set()
        for term in query_terms:
            if term in self.keyword_index:
                candidate_indices.update(self.keyword_index[term])
        
        # If no candidates found, use all chunks
        if not candidate_indices:
            candidate_indices = set(range(len(self.chunks)))
        
        # Calculate relevance scores
        scored_chunks = []
        for idx in candidate_indices:
            chunk = self.chunks[idx]
            score = self._calculate_relevance_score(chunk, query_terms)
            
            if score > 0:  # Only include chunks with some relevance
                chunk_with_score = chunk.copy()
                chunk_with_score['relevance_score'] = score
                scored_chunks.append(chunk_with_score)
        
        # Sort by relevance and return top_k
        scored_chunks.sort(key=lambda x: x['relevance_score'], reverse=True)
        
        # Add rank information
        for i, chunk in enumerate(scored_chunks[:top_k]):
            chunk['rank'] = i + 1
        
        return scored_chunks[:top_k]

    def generate_context_from_chunks(self, chunks: List[Dict[str, Any]]) -> str:
        """Generate formatted context from retrieved chunks."""
        if not chunks:
            return "No relevant medical guidelines found."
        
        context_parts = []
        context_parts.append("## Relevant Medical Guidelines\n")
        
        for i, chunk in enumerate(chunks, 1):
            context_parts.append(f"### Guideline {i} (Relevance: {chunk['relevance_score']:.2f})")
            context_parts.append(f"Source: {chunk['source']}")
            context_parts.append(f"{chunk['text']}")
            context_parts.append("")  # Empty line for separation
        
        return "\n".join(context_parts)

class SurgicalRiskRAGSimple:
    def __init__(self):
        """Initialize the simplified surgical risk RAG system."""
        self.rag_system = SimpleRAGSystem()
        
        # Risk explanation templates
        self.risk_templates = {
            'HIGH': {
                'factors': [
                    "High-risk surgical procedure with significant invasiveness",
                    "Advanced age increasing perioperative complications",
                    "Multiple comorbidities affecting surgical outcomes",
                    "Elevated ASA physical status classification",
                    "Abnormal laboratory values indicating organ dysfunction"
                ],
                'assessment': "This patient has HIGH surgical risk requiring intensive perioperative monitoring and optimization."
            },
            'ELEVATED': {
                'factors': [
                    "Moderately invasive surgical procedure",
                    "Some comorbidities present",
                    "Intermediate ASA classification",
                    "Some abnormal laboratory findings"
                ],
                'assessment': "This patient has ELEVATED surgical risk requiring careful perioperative management."
            },
            'MODERATE': {
                'factors': [
                    "Standard surgical procedure with moderate complexity",
                    "Limited comorbidities",
                    "Acceptable ASA classification"
                ],
                'assessment': "This patient has MODERATE surgical risk with standard perioperative care recommended."
            },
            'LOW': {
                'factors': [
                    "Minor surgical procedure",
                    "Minimal comorbidities",
                    "Good overall health status",
                    "Normal laboratory values"
                ],
                'assessment': "This patient has LOW surgical risk with routine perioperative care."
            }
        }

    def load_medical_guidelines(self) -> None:
        """Load and index medical guidelines."""
        guidelines_path = "/home/ubuntu/surgical-risk-mvp/data/guidelines/surgical_risk_guidelines.md"
        self.rag_system.load_guidelines(guidelines_path)
        print("Medical guidelines loaded successfully!")

    def generate_risk_explanation(self, patient_data: Dict[str, Any], 
                                risk_prediction: Dict[str, Any]) -> Dict[str, Any]:
        """Generate comprehensive risk explanation."""
        
        # Create queries based on patient factors
        queries = self._create_risk_queries(patient_data, risk_prediction)
        
        # Retrieve relevant chunks
        all_chunks = []
        for query in queries:
            chunks = self.rag_system.retrieve_relevant_chunks(query, top_k=2)
            all_chunks.extend(chunks)
        
        # Remove duplicates and get top chunks
        unique_chunks = []
        seen_ids = set()
        for chunk in all_chunks:
            if chunk['chunk_id'] not in seen_ids:
                seen_ids.add(chunk['chunk_id'])
                unique_chunks.append(chunk)
        
        # Sort by relevance and take top 3
        unique_chunks.sort(key=lambda x: x['relevance_score'], reverse=True)
        top_chunks = unique_chunks[:3]
        
        # Generate explanation
        explanation = self._generate_explanation(patient_data, risk_prediction, top_chunks)
        
        # Generate context
        context = self.rag_system.generate_context_from_chunks(top_chunks)
        
        return {
            'explanation': explanation,
            'retrieved_guidelines': top_chunks,
            'context_used': context
        }

    def _create_risk_queries(self, patient_data: Dict[str, Any], 
                           risk_prediction: Dict[str, Any]) -> List[str]:
        """Create targeted queries based on patient factors."""
        queries = []
        
        # Risk band query
        risk_band = risk_prediction['risk_band'].lower()
        queries.append(f"{risk_band} risk surgery")
        
        # Age-based query
        age = patient_data.get('age', 0)
        if age >= 80:
            queries.append("elderly geriatric surgery risk")
        elif age >= 70:
            queries.append("age elderly surgery complications")
        
        # ASA class query
        asa_class = patient_data.get('surgical_details', {}).get('asa_class', 0)
        if asa_class >= 3:
            queries.append(f"ASA class {asa_class} surgical risk")
        
        # Procedure complexity
        cpt_tier = patient_data.get('surgical_details', {}).get('cpt_invasiveness_tier', 0)
        if cpt_tier >= 4:
            queries.append("high risk surgery cardiac complications")
        
        # Specific conditions
        engineered = patient_data.get('engineered_features', {})
        if engineered.get('heart_failure', False):
            queries.append("heart failure surgical risk")
        if engineered.get('recent_mi', False):
            queries.append("myocardial infarction surgery")
        if engineered.get('creatinine_ge2', False):
            queries.append("kidney disease renal surgery risk")
        if engineered.get('bmi_ge40', False):
            queries.append("obesity surgical complications")
        
        # Emergency surgery
        if engineered.get('emergency_surgery', False):
            queries.append("emergency surgery risk factors")
        
        return queries

    def _generate_explanation(self, patient_data: Dict[str, Any], 
                            risk_prediction: Dict[str, Any], 
                            chunks: List[Dict[str, Any]]) -> Dict[str, str]:
        """Generate structured explanation based on patient data and guidelines."""
        
        risk_band = risk_prediction['risk_band']
        risk_score = risk_prediction['risk_score']
        
        # Get base template
        template = self.risk_templates.get(risk_band, self.risk_templates['MODERATE'])
        
        # Generate high-risk factors
        high_risk_factors = self._identify_high_risk_factors(patient_data)
        
        # Generate low-risk factors
        low_risk_factors = self._identify_low_risk_factors(patient_data)
        
        # Create comprehensive assessment
        overall_assessment = self._create_overall_assessment(
            patient_data, risk_prediction, chunks, template
        )
        
        return {
            'high_risk_factors': high_risk_factors,
            'low_risk_factors': low_risk_factors,
            'overall_assessment': overall_assessment
        }

    def _identify_high_risk_factors(self, patient_data: Dict[str, Any]) -> str:
        """Identify specific high-risk factors for the patient."""
        factors = []
        
        # Age factors
        age = patient_data.get('age', 0)
        if age >= 80:
            factors.append(f"Advanced age ({age} years) significantly increases perioperative risk")
        elif age >= 70:
            factors.append(f"Elderly age ({age} years) increases complication risk")
        
        # ASA class
        asa_class = patient_data.get('surgical_details', {}).get('asa_class', 0)
        if asa_class >= 4:
            factors.append("ASA Class IV indicates severe systemic disease with constant threat to life")
        elif asa_class >= 3:
            factors.append("ASA Class III indicates severe systemic disease with functional limitations")
        
        # Procedure complexity
        cpt_tier = patient_data.get('surgical_details', {}).get('cpt_invasiveness_tier', 0)
        if cpt_tier >= 4:
            factors.append("High-risk surgical procedure with significant invasiveness and complexity")
        
        # Specific conditions
        engineered = patient_data.get('engineered_features', {})
        if engineered.get('heart_failure', False):
            factors.append("Congestive heart failure increases cardiac complications risk")
        if engineered.get('recent_mi', False):
            factors.append("Recent myocardial infarction significantly elevates perioperative cardiac risk")
        if engineered.get('creatinine_ge2', False):
            factors.append("Elevated creatinine (≥2.0 mg/dL) indicates significant kidney dysfunction")
        if engineered.get('bmi_ge40', False):
            factors.append("Severe obesity (BMI ≥40) increases multiple perioperative complications")
        if engineered.get('emergency_surgery', False):
            factors.append("Emergency surgery prevents optimal preoperative optimization")
        
        # Lab abnormalities
        labs = patient_data.get('labs', {})
        if labs.get('hemoglobin', 15) < 10:
            factors.append(f"Anemia (Hemoglobin {labs['hemoglobin']} g/dL) increases transfusion risk")
        if labs.get('inr', 1.0) >= 2.0:
            factors.append(f"Elevated INR ({labs['inr']}) indicates increased bleeding risk")
        
        if not factors:
            factors.append("Multiple clinical factors contribute to elevated surgical risk")
        
        return ". ".join(factors) + "."

    def _identify_low_risk_factors(self, patient_data: Dict[str, Any]) -> str:
        """Identify protective or low-risk factors."""
        factors = []
        
        # Age factors
        age = patient_data.get('age', 0)
        if age < 65:
            factors.append(f"Younger age ({age} years) is associated with better surgical outcomes")
        
        # ASA class
        asa_class = patient_data.get('surgical_details', {}).get('asa_class', 0)
        if asa_class <= 2:
            factors.append("Low ASA classification indicates good baseline health status")
        
        # Procedure complexity
        cpt_tier = patient_data.get('surgical_details', {}).get('cpt_invasiveness_tier', 0)
        if cpt_tier <= 2:
            factors.append("Lower complexity surgical procedure reduces complication risk")
        
        # Normal lab values
        labs = patient_data.get('labs', {})
        if labs.get('creatinine', 2.0) < 1.2:
            factors.append("Normal kidney function (creatinine <1.2 mg/dL)")
        if labs.get('hemoglobin', 8) >= 12:
            factors.append("Normal hemoglobin levels reduce transfusion risk")
        if labs.get('inr', 2.0) < 1.3:
            factors.append("Normal coagulation studies indicate low bleeding risk")
        
        # Non-emergency
        engineered = patient_data.get('engineered_features', {})
        if not engineered.get('emergency_surgery', False):
            factors.append("Elective surgery allows for optimal preoperative preparation")
        
        if not factors:
            factors.append("Standard preoperative evaluation completed with appropriate risk stratification")
        
        return ". ".join(factors) + "."

    def _create_overall_assessment(self, patient_data: Dict[str, Any], 
                                 risk_prediction: Dict[str, Any], 
                                 chunks: List[Dict[str, Any]], 
                                 template: Dict[str, Any]) -> str:
        """Create comprehensive overall assessment."""
        
        risk_score = risk_prediction['risk_score']
        risk_band = risk_prediction['risk_band']
        
        assessment_parts = []
        
        # Risk score interpretation
        assessment_parts.append(f"This patient has a surgical risk score of {risk_score}, "
                              f"placing them in the {risk_band} risk category.")
        
        # Clinical context
        age = patient_data.get('age', 0)
        procedure = patient_data.get('surgical_details', {}).get('procedure_name', 'surgical procedure')
        assessment_parts.append(f"The {age}-year-old patient undergoing {procedure} "
                              f"requires {risk_band.lower()}-risk perioperative management.")
        
        # Recommendations based on risk level
        if risk_band == 'HIGH':
            assessment_parts.append("Intensive perioperative monitoring, possible ICU admission, "
                                   "and multidisciplinary care team involvement are recommended.")
        elif risk_band == 'ELEVATED':
            assessment_parts.append("Enhanced perioperative monitoring and careful attention to "
                                   "risk factor optimization are recommended.")
        elif risk_band == 'MODERATE':
            assessment_parts.append("Standard perioperative care with attention to identified "
                                   "risk factors is appropriate.")
        else:  # LOW
            assessment_parts.append("Routine perioperative care is appropriate for this low-risk patient.")
        
        # Evidence-based context from guidelines
        if chunks:
            assessment_parts.append("This assessment is based on established surgical risk "
                                   "assessment guidelines and validated risk stratification tools.")
        
        return " ".join(assessment_parts)

def test_simple_rag():
    """Test the simplified RAG system."""
    print("Testing Simplified RAG System...")
    
    # Initialize system
    rag = SurgicalRiskRAGSimple()
    rag.load_medical_guidelines()
    
    # Test retrieval
    test_query = "high-risk surgery cardiac complications"
    chunks = rag.rag_system.retrieve_relevant_chunks(test_query, top_k=3)
    
    print(f"\nTest Query: '{test_query}'")
    print(f"Retrieved {len(chunks)} relevant chunks:")
    for chunk in chunks:
        print(f"Score: {chunk['relevance_score']:.2f} - {chunk['text'][:100]}...")
    
    # Test with sample patient
    sample_patient = {
        'age': 75,
        'sex': 'M',
        'bmi': 32,
        'surgical_details': {
            'procedure_name': 'Cardiac surgery',
            'asa_class': 4,
            'cpt_invasiveness_tier': 4
        },
        'labs': {
            'creatinine': 2.1,
            'hemoglobin': 9.5,
            'inr': 1.8
        },
        'medical_history': {
            'conditions': ['Heart failure', 'Diabetes mellitus type 2']
        },
        'engineered_features': {
            'high_risk_surgery': True,
            'heart_failure': True,
            'creatinine_ge2': True,
            'asa_ge4': True,
            'emergency_surgery': False
        }
    }
    
    sample_prediction = {
        'risk_score': 75,
        'risk_band': 'HIGH',
        'risk_probability': 0.75
    }
    
    print("\nTesting risk explanation generation...")
    result = rag.generate_risk_explanation(sample_patient, sample_prediction)
    
    print("\nGenerated Explanation:")
    print("High-risk factors:", result['explanation']['high_risk_factors'])
    print("\nLow-risk factors:", result['explanation']['low_risk_factors'])
    print("\nOverall assessment:", result['explanation']['overall_assessment'])
    
    print(f"\nRetrieved {len(result['retrieved_guidelines'])} guideline chunks")
    print("\nSimplified RAG system test completed successfully!")

if __name__ == "__main__":
    test_simple_rag()

