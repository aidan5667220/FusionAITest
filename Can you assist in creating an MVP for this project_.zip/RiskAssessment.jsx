import { useState, useEffect } from 'react'
import { 
  Activity, 
  User, 
  Heart, 
  Stethoscope, 
  FileText, 
  AlertTriangle,
  CheckCircle,
  Info,
  Send,
  RefreshCw
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'sonner'

const RiskAssessment = ({ currentPatient, setCurrentPatient, addToHistory }) => {
  const [patientData, setPatientData] = useState({
    patient_id: '',
    age: '',
    sex: '',
    height_cm: '',
    weight_kg: '',
    bmi: '',
    labs: {
      creatinine: '',
      hemoglobin: '',
      sodium: '',
      potassium: '',
      alt: '',
      inr: ''
    },
    vitals: {
      sbp: '',
      dbp: '',
      heart_rate: '',
      spo2: '',
      temperature: ''
    },
    surgical_details: {
      procedure_name: '',
      cpt_invasiveness_tier: '',
      asa_class: '',
      procedure_duration_min: '',
      emergency_case: false
    },
    medical_history: {
      conditions: [],
      medications: [],
      allergies: []
    }
  })

  const [assessment, setAssessment] = useState(null)
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('demographics')

  useEffect(() => {
    if (currentPatient) {
      setPatientData(currentPatient)
      calculateBMI(currentPatient.height_cm, currentPatient.weight_kg)
    }
  }, [currentPatient])

  const calculateBMI = (height, weight) => {
    if (height && weight) {
      const heightM = height / 100
      const bmi = (weight / (heightM * heightM)).toFixed(1)
      setPatientData(prev => ({ ...prev, bmi: parseFloat(bmi) }))
    }
  }

  const handleInputChange = (section, field, value) => {
    if (section) {
      setPatientData(prev => ({
        ...prev,
        [section]: {
          ...prev[section],
          [field]: value
        }
      }))
    } else {
      setPatientData(prev => ({
        ...prev,
        [field]: value
      }))
    }

    // Auto-calculate BMI
    if (field === 'height_cm' || field === 'weight_kg') {
      const height = field === 'height_cm' ? value : patientData.height_cm
      const weight = field === 'weight_kg' ? value : patientData.weight_kg
      calculateBMI(height, weight)
    }
  }

  const handleArrayInputChange = (section, field, value) => {
    const items = value.split(',').map(item => item.trim()).filter(item => item)
    setPatientData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: items
      }
    }))
  }

  const validateForm = () => {
    const required = ['age', 'sex', 'bmi']
    const missing = required.filter(field => !patientData[field])
    
    if (missing.length > 0) {
      toast.error(`Please fill in required fields: ${missing.join(', ')}`)
      return false
    }

    if (!patientData.surgical_details.asa_class) {
      toast.error("ASA Class is required for risk assessment")
      return false
    }

    return true
  }

  const submitAssessment = async () => {
    if (!validateForm()) return

    setLoading(true)
    try {
      const response = await fetch('/api/risk/assess-risk', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...patientData,
          created_at: new Date().toISOString()
        })
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()
      setAssessment(result)
      addToHistory(result)
      
      toast.success(`Risk score: ${result.risk_assessment.risk_score} (${result.risk_assessment.risk_band})`)

    } catch (error) {
      console.error('Assessment error:', error)
      toast.error("Unable to complete risk assessment. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const loadDemoPatient = async () => {
    try {
      const response = await fetch('/api/risk/demo-patients')
      if (response.ok) {
        const data = await response.json()
        if (data.demo_patients && data.demo_patients.length > 0) {
          const randomPatient = data.demo_patients[Math.floor(Math.random() * data.demo_patients.length)]
          setPatientData(randomPatient.full_data)
          setCurrentPatient(randomPatient.full_data)
          toast.success(`Loaded ${randomPatient.age}yr ${randomPatient.sex} patient`)
        }
      }
    } catch (error) {
      console.error('Error loading demo patient:', error)
    }
  }

  const clearForm = () => {
    setPatientData({
      patient_id: '',
      age: '',
      sex: '',
      height_cm: '',
      weight_kg: '',
      bmi: '',
      labs: {
        creatinine: '',
        hemoglobin: '',
        sodium: '',
        potassium: '',
        alt: '',
        inr: ''
      },
      vitals: {
        sbp: '',
        dbp: '',
        heart_rate: '',
        spo2: '',
        temperature: ''
      },
      surgical_details: {
        procedure_name: '',
        cpt_invasiveness_tier: '',
        asa_class: '',
        procedure_duration_min: '',
        emergency_case: false
      },
      medical_history: {
        conditions: [],
        medications: [],
        allergies: []
      }
    })
    setAssessment(null)
    setCurrentPatient(null)
  }

  const getRiskBadgeColor = (riskScore) => {
    if (riskScore <= 20) return 'bg-green-100 text-green-800 border-green-200'
    if (riskScore <= 40) return 'bg-blue-100 text-blue-800 border-blue-200'
    if (riskScore <= 60) return 'bg-yellow-100 text-yellow-800 border-yellow-200'
    if (riskScore <= 80) return 'bg-red-100 text-red-800 border-red-200'
    return 'bg-red-200 text-red-900 border-red-300'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Surgical Risk Assessment</h2>
          <p className="text-gray-600">Enter patient information to calculate surgical risk</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={loadDemoPatient}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Load Demo
          </Button>
          <Button variant="outline" onClick={clearForm}>
            Clear Form
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Patient Input Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 mr-2" />
                Patient Information
              </CardTitle>
              <CardDescription>
                Complete patient data for accurate risk assessment
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="demographics">Demographics</TabsTrigger>
                  <TabsTrigger value="labs">Labs</TabsTrigger>
                  <TabsTrigger value="vitals">Vitals</TabsTrigger>
                  <TabsTrigger value="surgical">Surgical</TabsTrigger>
                </TabsList>

                <TabsContent value="demographics" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="patient_id">Patient ID</Label>
                      <Input
                        id="patient_id"
                        value={patientData.patient_id}
                        onChange={(e) => handleInputChange(null, 'patient_id', e.target.value)}
                        placeholder="PAT_123456"
                      />
                    </div>
                    <div>
                      <Label htmlFor="age">Age *</Label>
                      <Input
                        id="age"
                        type="number"
                        value={patientData.age}
                        onChange={(e) => handleInputChange(null, 'age', parseInt(e.target.value) || '')}
                        placeholder="65"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="sex">Sex *</Label>
                      <Select value={patientData.sex} onValueChange={(value) => handleInputChange(null, 'sex', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select sex" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="M">Male</SelectItem>
                          <SelectItem value="F">Female</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="height">Height (cm)</Label>
                      <Input
                        id="height"
                        type="number"
                        value={patientData.height_cm}
                        onChange={(e) => handleInputChange(null, 'height_cm', parseFloat(e.target.value) || '')}
                        placeholder="175"
                      />
                    </div>
                    <div>
                      <Label htmlFor="weight">Weight (kg)</Label>
                      <Input
                        id="weight"
                        type="number"
                        value={patientData.weight_kg}
                        onChange={(e) => handleInputChange(null, 'weight_kg', parseFloat(e.target.value) || '')}
                        placeholder="80"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="bmi">BMI *</Label>
                    <Input
                      id="bmi"
                      type="number"
                      value={patientData.bmi}
                      onChange={(e) => handleInputChange(null, 'bmi', parseFloat(e.target.value) || '')}
                      placeholder="26.1"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="conditions">Medical Conditions</Label>
                    <Textarea
                      id="conditions"
                      value={patientData.medical_history.conditions.join(', ')}
                      onChange={(e) => handleArrayInputChange('medical_history', 'conditions', e.target.value)}
                      placeholder="Hypertension, Diabetes mellitus type 2, ..."
                      rows={2}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="labs" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="creatinine">Creatinine (mg/dL)</Label>
                      <Input
                        id="creatinine"
                        type="number"
                        step="0.1"
                        value={patientData.labs.creatinine}
                        onChange={(e) => handleInputChange('labs', 'creatinine', parseFloat(e.target.value) || '')}
                        placeholder="1.0"
                      />
                    </div>
                    <div>
                      <Label htmlFor="hemoglobin">Hemoglobin (g/dL)</Label>
                      <Input
                        id="hemoglobin"
                        type="number"
                        step="0.1"
                        value={patientData.labs.hemoglobin}
                        onChange={(e) => handleInputChange('labs', 'hemoglobin', parseFloat(e.target.value) || '')}
                        placeholder="13.5"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="sodium">Sodium (mEq/L)</Label>
                      <Input
                        id="sodium"
                        type="number"
                        value={patientData.labs.sodium}
                        onChange={(e) => handleInputChange('labs', 'sodium', parseInt(e.target.value) || '')}
                        placeholder="140"
                      />
                    </div>
                    <div>
                      <Label htmlFor="potassium">Potassium (mEq/L)</Label>
                      <Input
                        id="potassium"
                        type="number"
                        step="0.1"
                        value={patientData.labs.potassium}
                        onChange={(e) => handleInputChange('labs', 'potassium', parseFloat(e.target.value) || '')}
                        placeholder="4.0"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="alt">ALT (U/L)</Label>
                      <Input
                        id="alt"
                        type="number"
                        value={patientData.labs.alt}
                        onChange={(e) => handleInputChange('labs', 'alt', parseInt(e.target.value) || '')}
                        placeholder="25"
                      />
                    </div>
                    <div>
                      <Label htmlFor="inr">INR</Label>
                      <Input
                        id="inr"
                        type="number"
                        step="0.1"
                        value={patientData.labs.inr}
                        onChange={(e) => handleInputChange('labs', 'inr', parseFloat(e.target.value) || '')}
                        placeholder="1.1"
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="vitals" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="sbp">Systolic BP (mmHg)</Label>
                      <Input
                        id="sbp"
                        type="number"
                        value={patientData.vitals.sbp}
                        onChange={(e) => handleInputChange('vitals', 'sbp', parseInt(e.target.value) || '')}
                        placeholder="130"
                      />
                    </div>
                    <div>
                      <Label htmlFor="dbp">Diastolic BP (mmHg)</Label>
                      <Input
                        id="dbp"
                        type="number"
                        value={patientData.vitals.dbp}
                        onChange={(e) => handleInputChange('vitals', 'dbp', parseInt(e.target.value) || '')}
                        placeholder="80"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="heart_rate">Heart Rate (bpm)</Label>
                      <Input
                        id="heart_rate"
                        type="number"
                        value={patientData.vitals.heart_rate}
                        onChange={(e) => handleInputChange('vitals', 'heart_rate', parseInt(e.target.value) || '')}
                        placeholder="75"
                      />
                    </div>
                    <div>
                      <Label htmlFor="spo2">SpO2 (%)</Label>
                      <Input
                        id="spo2"
                        type="number"
                        value={patientData.vitals.spo2}
                        onChange={(e) => handleInputChange('vitals', 'spo2', parseInt(e.target.value) || '')}
                        placeholder="98"
                      />
                    </div>
                    <div>
                      <Label htmlFor="temperature">Temperature (°F)</Label>
                      <Input
                        id="temperature"
                        type="number"
                        step="0.1"
                        value={patientData.vitals.temperature}
                        onChange={(e) => handleInputChange('vitals', 'temperature', parseFloat(e.target.value) || '')}
                        placeholder="98.6"
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="surgical" className="space-y-4">
                  <div>
                    <Label htmlFor="procedure">Procedure Name</Label>
                    <Input
                      id="procedure"
                      value={patientData.surgical_details.procedure_name}
                      onChange={(e) => handleInputChange('surgical_details', 'procedure_name', e.target.value)}
                      placeholder="Cholecystectomy"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="asa_class">ASA Class *</Label>
                      <Select 
                        value={patientData.surgical_details.asa_class.toString()} 
                        onValueChange={(value) => handleInputChange('surgical_details', 'asa_class', parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select ASA class" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">ASA I - Normal healthy</SelectItem>
                          <SelectItem value="2">ASA II - Mild systemic disease</SelectItem>
                          <SelectItem value="3">ASA III - Severe systemic disease</SelectItem>
                          <SelectItem value="4">ASA IV - Life-threatening disease</SelectItem>
                          <SelectItem value="5">ASA V - Moribund patient</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="cpt_tier">CPT Invasiveness Tier</Label>
                      <Select 
                        value={patientData.surgical_details.cpt_invasiveness_tier.toString()} 
                        onValueChange={(value) => handleInputChange('surgical_details', 'cpt_invasiveness_tier', parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select tier" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">Tier 1 - Minor</SelectItem>
                          <SelectItem value="2">Tier 2 - Intermediate</SelectItem>
                          <SelectItem value="3">Tier 3 - Major</SelectItem>
                          <SelectItem value="4">Tier 4 - Complex</SelectItem>
                          <SelectItem value="5">Tier 5 - High-risk</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="duration">Procedure Duration (minutes)</Label>
                    <Input
                      id="duration"
                      type="number"
                      value={patientData.surgical_details.procedure_duration_min}
                      onChange={(e) => handleInputChange('surgical_details', 'procedure_duration_min', parseInt(e.target.value) || '')}
                      placeholder="120"
                    />
                  </div>
                </TabsContent>
              </Tabs>

              <div className="mt-6 flex justify-end">
                <Button 
                  onClick={submitAssessment} 
                  disabled={loading}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Assessing...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Assess Risk
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Assessment Results */}
        <div className="space-y-6">
          {assessment ? (
            <>
              {/* Risk Score Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="h-5 w-5 mr-2" />
                    Risk Assessment
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="mb-4">
                    <div className="text-4xl font-bold text-gray-900 mb-2">
                      {assessment.risk_assessment.risk_score}
                    </div>
                    <Badge className={`text-lg px-4 py-2 ${getRiskBadgeColor(assessment.risk_assessment.risk_score)}`}>
                      {assessment.risk_assessment.risk_band} RISK
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">
                    Risk Probability: {(assessment.risk_assessment.risk_probability * 100).toFixed(1)}%
                  </p>
                </CardContent>
              </Card>

              {/* Explanations */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="h-5 w-5 mr-2" />
                    Risk Factors
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex items-center mb-2">
                      <AlertTriangle className="h-4 w-4 text-red-500 mr-2" />
                      <span className="font-medium text-red-700">High-Risk Factors</span>
                    </div>
                    <p className="text-sm text-gray-700 bg-red-50 p-3 rounded-lg">
                      {assessment.explanations.high_risk_factors}
                    </p>
                  </div>

                  <div>
                    <div className="flex items-center mb-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      <span className="font-medium text-green-700">Protective Factors</span>
                    </div>
                    <p className="text-sm text-gray-700 bg-green-50 p-3 rounded-lg">
                      {assessment.explanations.low_risk_factors}
                    </p>
                  </div>

                  <div>
                    <div className="flex items-center mb-2">
                      <Info className="h-4 w-4 text-blue-500 mr-2" />
                      <span className="font-medium text-blue-700">Overall Assessment</span>
                    </div>
                    <p className="text-sm text-gray-700 bg-blue-50 p-3 rounded-lg">
                      {assessment.explanations.overall_assessment}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Guidelines Used */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Stethoscope className="h-5 w-5 mr-2" />
                    Evidence Base
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    Assessment based on {assessment.guidelines_used} medical guidelines and 
                    validated risk stratification tools.
                  </p>
                  <div className="mt-2 text-xs text-gray-500">
                    Model: XGBoost with Isotonic Calibration
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2" />
                  Risk Assessment
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center py-8">
                <Activity className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-500">
                  Complete patient information and click "Assess Risk" to generate risk score
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

export default RiskAssessment

