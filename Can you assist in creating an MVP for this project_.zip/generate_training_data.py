"""
Generate larger training dataset for ML model training
"""

import json
import sys
import os
sys.path.append('/home/ubuntu/surgical-risk-mvp/data')

from synthetic_data_generator import SyntheticMedicalDataGenerator

def main():
    print("Generating training dataset for Surgical Risk Assessment MVP...")
    
    # Initialize generator
    generator = SyntheticMedicalDataGenerator(seed=42)
    
    # Generate training dataset (1000 patients)
    print("Generating training dataset (1000 patients)...")
    training_patients = generator.generate_dataset(
        n_patients=1000,
        high_risk_ratio=0.25,  # 25% high-risk
        low_risk_ratio=0.35    # 35% low-risk, 40% random
    )
    
    # Save training data
    with open('/home/ubuntu/surgical-risk-mvp/data/synthetic/training_patients.json', 'w') as f:
        json.dump(training_patients, f, indent=2)
    
    print(f"Training dataset saved: {len(training_patients)} patients")
    
    # Generate validation dataset (200 patients)
    print("Generating validation dataset (200 patients)...")
    generator_val = SyntheticMedicalDataGenerator(seed=123)  # Different seed
    validation_patients = generator_val.generate_dataset(
        n_patients=200,
        high_risk_ratio=0.25,
        low_risk_ratio=0.35
    )
    
    # Save validation data
    with open('/home/ubuntu/surgical-risk-mvp/data/synthetic/validation_patients.json', 'w') as f:
        json.dump(validation_patients, f, indent=2)
    
    print(f"Validation dataset saved: {len(validation_patients)} patients")
    
    # Calculate outcome statistics
    train_outcomes = [p['outcome_30day_complication'] for p in training_patients]
    val_outcomes = [p['outcome_30day_complication'] for p in validation_patients]
    
    print(f"\nDataset Statistics:")
    print(f"Training set: {len(training_patients)} patients, {sum(train_outcomes)} complications ({sum(train_outcomes)/len(train_outcomes)*100:.1f}%)")
    print(f"Validation set: {len(validation_patients)} patients, {sum(val_outcomes)} complications ({sum(val_outcomes)/len(val_outcomes)*100:.1f}%)")
    
    # Sample risk score distribution
    train_scores = [p['true_risk_score'] for p in training_patients]
    print(f"\nRisk Score Distribution (Training):")
    print(f"Mean: {sum(train_scores)/len(train_scores):.1f}")
    print(f"Min: {min(train_scores)}, Max: {max(train_scores)}")
    
    # Risk band distribution
    risk_bands = {'LOW': 0, 'MODERATE': 0, 'ELEVATED': 0, 'HIGH': 0, 'VERY HIGH': 0}
    for score in train_scores:
        if score <= 20:
            risk_bands['LOW'] += 1
        elif score <= 40:
            risk_bands['MODERATE'] += 1
        elif score <= 60:
            risk_bands['ELEVATED'] += 1
        elif score <= 80:
            risk_bands['HIGH'] += 1
        else:
            risk_bands['VERY HIGH'] += 1
    
    print(f"\nRisk Band Distribution:")
    for band, count in risk_bands.items():
        print(f"{band}: {count} ({count/len(train_scores)*100:.1f}%)")
    
    print("\nDataset generation completed successfully!")

if __name__ == "__main__":
    main()

