# VS Code Local Development Setup Guide
## Surgical Risk Assessment MVP - Fusion Medical

**Author:** Manus AI  
**Date:** January 2025  
**Version:** 1.0

---

## Table of Contents

1. [Prerequisites and Environment Setup](#prerequisites-and-environment-setup)
2. [VS Code Configuration](#vs-code-configuration)
3. [Project Structure and Workspace Setup](#project-structure-and-workspace-setup)
4. [Backend Development Environment](#backend-development-environment)
5. [Frontend Development Environment](#frontend-development-environment)
6. [Debugging and Development Workflow](#debugging-and-development-workflow)
7. [Common Issues and Troubleshooting](#common-issues-and-troubleshooting)

---

## Prerequisites and Environment Setup

Setting up a robust local development environment for the Surgical Risk Assessment MVP requires careful attention to both the Python backend ecosystem and the Node.js frontend environment. The complexity of this medical AI application demands a well-configured development setup that can handle machine learning workflows, web development, and data processing simultaneously.

The foundation of our development environment begins with ensuring that your system meets the minimum requirements for running both the Flask backend and React frontend components. Your development machine should have at least 8GB of RAM to comfortably handle the XGBoost model loading, vector database operations, and concurrent development servers. Additionally, having an SSD is highly recommended as the application involves frequent file I/O operations for model loading, synthetic data generation, and vector database queries.

Python 3.11 or higher is essential for this project, as we leverage several modern Python features and libraries that require recent Python versions. The XGBoost library, in particular, benefits from the performance improvements and bug fixes available in Python 3.11. Similarly, our React frontend requires Node.js 18 or higher to support the modern JavaScript features and build tools we utilize.

Git version control is crucial not only for code management but also for handling the large model files and datasets that are part of this project. We recommend configuring Git LFS (Large File Storage) to efficiently handle the machine learning model files and any large synthetic datasets you might generate during development.




## VS Code Configuration

Visual Studio Code serves as the ideal integrated development environment for this project due to its excellent support for both Python and JavaScript ecosystems, robust debugging capabilities, and extensive extension marketplace. The configuration of VS Code for this medical AI application requires careful selection and setup of extensions that will enhance your development productivity while maintaining code quality and consistency.

The Python extension by Microsoft forms the cornerstone of our backend development setup. This extension provides comprehensive support for Python development, including IntelliSense code completion, debugging capabilities, code formatting with Black or autopep8, and integrated terminal support. When working with the Flask backend, the Python extension automatically detects virtual environments and provides seamless integration with pip package management.

For the machine learning components of our application, the Jupyter extension proves invaluable. While our primary development occurs in standard Python files, the ability to create and run Jupyter notebooks within VS Code is essential for data exploration, model experimentation, and debugging complex ML pipelines. The Jupyter extension allows you to run individual code cells, visualize data frames, and interact with the XGBoost model in an exploratory manner.

The ES7+ React/Redux/React-Native snippets extension significantly accelerates frontend development by providing intelligent code snippets for React components, hooks, and common patterns. This extension is particularly useful when creating new components for the patient assessment forms or dashboard visualizations. The snippets follow modern React best practices and help maintain consistency across the codebase.

Prettier and ESLint extensions work in tandem to maintain code quality and formatting consistency across the React frontend. Prettier handles automatic code formatting, ensuring that all team members follow the same style guidelines, while ESLint catches potential bugs and enforces coding standards. These tools are especially important in a medical application where code quality directly impacts patient safety.

The GitLens extension enhances Git integration within VS Code, providing inline blame annotations, commit history visualization, and advanced Git workflow features. Given the collaborative nature of medical software development and the need for detailed change tracking, GitLens becomes an essential tool for understanding code evolution and maintaining audit trails.

For database and API development, the REST Client extension allows you to test API endpoints directly within VS Code without switching to external tools like Postman. This is particularly useful when developing and testing the risk assessment endpoints, as you can create .http files with sample requests and responses that serve as both documentation and testing tools.

The Python Docstring Generator extension helps maintain comprehensive documentation for the machine learning and data processing functions. Given the complexity of medical algorithms and the need for clear documentation in healthcare applications, this extension ensures that all functions have properly formatted docstrings that explain parameters, return values, and medical context.

Setting up a proper workspace configuration involves creating a .vscode directory in your project root with carefully crafted settings.json, launch.json, and tasks.json files. The settings.json file should specify Python interpreter paths, formatting preferences, and extension-specific configurations. The launch.json file defines debugging configurations for both the Flask backend and React frontend, allowing you to set breakpoints and step through code execution. The tasks.json file automates common development tasks such as running tests, starting development servers, and building the application.


## Project Structure and Workspace Setup

The Surgical Risk Assessment MVP follows a carefully designed project structure that separates concerns while maintaining clear relationships between components. Understanding this structure is crucial for effective development and maintenance of the application. The architecture reflects best practices for full-stack medical applications, with clear separation between data processing, machine learning, backend API, and frontend presentation layers.

The root directory contains several key subdirectories, each serving a specific purpose in the application ecosystem. The `backend` directory houses the Flask application that serves as the API layer, handling HTTP requests, coordinating with the machine learning models, and managing data flow. The `frontend` directory contains the React application that provides the user interface for clinicians to input patient data and view risk assessments. The `models` directory contains all machine learning related code, including model training scripts, the trained XGBoost model files, and model evaluation utilities. The `data` directory manages synthetic data generation, feature engineering pipelines, and sample datasets used for development and testing.

The `vector_db` directory contains the RAG (Retrieval-Augmented Generation) system implementation, including the vector database for medical guidelines and the retrieval mechanisms that provide evidence-based explanations for risk assessments. This separation allows for independent development and testing of the RAG system while maintaining clean interfaces with the main application.

Within the backend directory, the Flask application follows a blueprint-based architecture that promotes modularity and maintainability. The `src` directory contains the main application code, with separate modules for different functional areas. The `routes` subdirectory contains Flask blueprints that define API endpoints, with `risk_assessment.py` handling all risk-related endpoints and `user.py` managing user-related functionality. The `models` subdirectory contains database models and data structures, while the `utils` directory houses utility functions for data validation, error handling, and common operations.

The frontend React application employs a component-based architecture that promotes reusability and maintainability. The `src` directory contains the main application code, with the `components` subdirectory organized by functionality. The `ui` subdirectory contains reusable UI components such as buttons, forms, and cards that maintain consistent styling across the application. The main application components like `Dashboard`, `RiskAssessment`, and `PatientHistory` are located in the root of the components directory.

Configuration management across the application requires careful attention to environment-specific settings. The backend uses environment variables for configuration, with a `.env` file for local development settings and production configurations managed through deployment-specific mechanisms. The frontend uses environment variables prefixed with `REACT_APP_` to configure API endpoints and other runtime settings.

The workspace setup in VS Code should include a multi-root workspace configuration that allows you to work with both the backend and frontend simultaneously while maintaining separate configurations for each. This approach enables you to have different Python interpreters, Node.js versions, and extension settings for each part of the application while still maintaining a unified development experience.

Version control configuration requires special attention due to the presence of large model files and generated datasets. The `.gitignore` file should exclude virtual environments, node_modules, build artifacts, and temporary files while ensuring that essential configuration files and documentation are tracked. Git LFS should be configured to handle model files, large datasets, and any binary assets that exceed GitHub's file size limits.

Development workflow optimization involves setting up automated tasks for common operations such as starting development servers, running tests, and building the application. VS Code tasks can be configured to start both the Flask backend and React frontend simultaneously, making it easy to begin development with a single command. Similarly, debugging configurations should be set up to allow simultaneous debugging of both backend and frontend components.


## Backend Development Environment

The Flask backend development environment requires careful setup of Python virtual environments, dependency management, and development tools to ensure consistent and reliable development across different machines and deployment targets. The backend serves as the critical bridge between the machine learning models and the frontend interface, handling complex medical data processing and risk calculations that demand robust error handling and comprehensive testing.

Virtual environment management forms the foundation of Python development for this project. Using `venv` or `conda`, you should create an isolated Python environment specifically for the Surgical Risk Assessment application. This isolation prevents conflicts between different projects and ensures that the specific versions of scientific computing libraries like NumPy, Pandas, and XGBoost remain consistent across development and production environments. The virtual environment should be created with Python 3.11 to take advantage of performance improvements and ensure compatibility with all project dependencies.

Dependency management requires careful attention to version pinning and compatibility matrices. The `requirements.txt` file should specify exact versions for critical dependencies like Flask, XGBoost, and scikit-learn to ensure reproducible builds. Development dependencies such as pytest, black, and flake8 should be separated into a `requirements-dev.txt` file to avoid installing unnecessary packages in production environments. The machine learning dependencies, particularly XGBoost and scikit-learn, require specific versions that are compatible with the trained model files.

Flask application configuration involves setting up proper development and production configurations that handle database connections, API keys, and environment-specific settings. The application factory pattern used in the project allows for flexible configuration management, with different settings for development, testing, and production environments. Environment variables should be used for sensitive configuration such as database URLs and API keys, with a `.env` file providing default values for local development.

Database setup for the application involves configuring SQLite for development and preparing for PostgreSQL in production environments. The SQLAlchemy ORM provides database abstraction that allows for easy switching between database backends. Migration management using Flask-Migrate ensures that database schema changes can be applied consistently across different environments. The database models should include proper indexing for performance and foreign key constraints for data integrity.

API development workflow involves setting up proper request validation, error handling, and response formatting. The Flask-RESTful extension provides a structured approach to API development with automatic request parsing and response serialization. Input validation should use marshmallow schemas to ensure that patient data meets medical standards and prevents invalid data from reaching the machine learning models. Error handling should provide meaningful error messages while avoiding exposure of sensitive system information.

Testing infrastructure requires comprehensive unit tests, integration tests, and API endpoint tests. The pytest framework provides excellent support for testing Flask applications, with fixtures for database setup and teardown. Mock objects should be used to isolate tests from external dependencies such as the machine learning models and vector database. Test coverage should be monitored using coverage.py to ensure that critical medical algorithms are thoroughly tested.

Development server configuration should enable hot reloading for rapid development cycles while maintaining stability for debugging complex medical algorithms. The Flask development server provides automatic reloading when code changes are detected, but care must be taken to ensure that model loading and initialization occur properly during restarts. Logging configuration should provide detailed information about request processing, model predictions, and error conditions to facilitate debugging.

Performance monitoring during development involves tracking response times, memory usage, and model inference latency. The Flask application should include middleware for request timing and memory profiling to identify performance bottlenecks. The machine learning model loading and prediction times should be monitored to ensure that the application meets performance requirements for clinical use.

Security considerations during development include proper handling of patient data, even when using synthetic datasets. Input sanitization, SQL injection prevention, and proper authentication mechanisms should be implemented from the beginning of development. The application should follow OWASP guidelines for web application security, with particular attention to medical data protection requirements.


## Frontend Development Environment

The React frontend development environment requires careful configuration of Node.js, package management, build tools, and development servers to create a responsive and intuitive interface for medical professionals. The frontend serves as the primary interaction point for clinicians, requiring exceptional attention to usability, accessibility, and performance while handling complex medical data input and risk visualization.

Node.js and npm configuration forms the foundation of the frontend development environment. Node.js version 18 or higher is required to support the modern JavaScript features and build tools used in the React application. The npm package manager should be configured with appropriate registry settings and cache configurations to ensure reliable dependency installation. Consider using npm's package-lock.json file to ensure consistent dependency versions across different development machines and deployment environments.

React application setup involves configuring the development server, build tools, and hot module replacement for efficient development workflows. The Create React App foundation provides a robust starting point with pre-configured webpack, Babel, and ESLint settings optimized for React development. The development server should be configured to proxy API requests to the Flask backend, enabling seamless full-stack development without CORS complications.

Component architecture planning requires careful consideration of the medical workflow and user interface requirements. The component hierarchy should reflect the clinical decision-making process, with clear separation between data input components, visualization components, and navigation elements. Reusable UI components should be developed for common medical interface patterns such as patient information forms, risk score displays, and clinical decision support alerts.

State management configuration involves setting up React hooks and context providers to manage application state effectively. The patient data, assessment results, and user interface state should be managed through a combination of local component state and global application state. Consider implementing state persistence to prevent data loss during development and provide a better user experience for clinicians who may need to step away from assessments.

Styling and theming setup requires configuration of CSS modules, styled-components, or a CSS framework that supports medical application requirements. The styling system should accommodate accessibility requirements, responsive design for different screen sizes, and theming capabilities for different clinical environments. Medical applications often require specific color schemes and typography that comply with healthcare usability standards.

Development tooling configuration includes setting up ESLint for code quality, Prettier for code formatting, and testing frameworks for component testing. The ESLint configuration should include rules specific to React development and accessibility requirements. Testing setup should include Jest for unit testing and React Testing Library for component testing, with particular attention to testing user interactions and form validation.

API integration setup involves configuring HTTP clients, error handling, and data transformation layers for communication with the Flask backend. The axios library provides robust HTTP client capabilities with interceptors for request/response transformation and error handling. API integration should include proper loading states, error handling, and retry mechanisms to provide a smooth user experience even when network conditions are suboptimal.

Build and deployment configuration requires setting up production builds, asset optimization, and deployment pipelines. The build process should include code splitting, asset minification, and bundle analysis to ensure optimal performance in clinical environments. Environment-specific configurations should be managed through environment variables to support different deployment targets.

Performance optimization during development involves monitoring bundle sizes, render performance, and memory usage. React Developer Tools provide excellent insights into component rendering and state changes. Performance monitoring should include tracking of user interactions, form submission times, and data visualization rendering to ensure that the application meets the responsiveness requirements for clinical use.

Accessibility configuration requires implementing ARIA labels, keyboard navigation, and screen reader support to ensure that the application is usable by healthcare professionals with different abilities. The accessibility testing should be integrated into the development workflow with automated testing tools and manual testing procedures. Medical applications have particularly stringent accessibility requirements due to the critical nature of the information being processed.

Security considerations for the frontend include proper handling of sensitive medical data, secure communication with the backend, and protection against common web vulnerabilities. Input validation should be implemented on the frontend for immediate user feedback while relying on backend validation for security. The application should implement proper session management and data encryption for any sensitive information stored in the browser.


## Debugging and Development Workflow

Effective debugging and development workflow configuration is crucial for maintaining productivity while developing complex medical AI applications. The integration of machine learning models, web APIs, and user interfaces creates multiple layers where issues can arise, requiring sophisticated debugging strategies and tools to identify and resolve problems efficiently.

VS Code debugging configuration for the Flask backend involves setting up launch configurations that allow you to set breakpoints, inspect variables, and step through code execution. The Python debugger should be configured to handle the Flask application startup, including model loading and database initialization. Debugging configurations should include options for running the application with different environment settings, enabling you to test various scenarios without modifying code.

The debugging setup should include configurations for testing individual components such as the machine learning model inference, RAG system queries, and API endpoint handlers. Conditional breakpoints can be particularly useful when debugging medical algorithms, allowing you to stop execution only when specific patient conditions or risk thresholds are encountered. The debugger should be configured to handle the asynchronous nature of some operations and the complex data structures used in medical applications.

Frontend debugging configuration requires setting up Chrome DevTools integration and React Developer Tools for comprehensive component inspection and state debugging. The React debugging setup should include source map configuration to enable debugging of the original TypeScript or JSX code rather than the compiled JavaScript. Debugging configurations should support hot reloading while maintaining breakpoint persistence across code changes.

Network debugging capabilities are essential for troubleshooting API communication between the frontend and backend. The debugging setup should include network request inspection, response analysis, and error tracking. Mock API responses can be configured for frontend development when the backend is unavailable or when testing specific error conditions.

Logging configuration across the application stack provides crucial insights into application behavior and performance. The Flask backend should implement structured logging with appropriate log levels for different types of events. Medical applications require detailed audit logs for compliance purposes, so the logging configuration should capture user actions, data access, and system events with appropriate detail levels.

Frontend logging should capture user interactions, API requests, and error conditions while being mindful of patient privacy requirements. Client-side error tracking should be implemented to capture and report JavaScript errors that might not be immediately apparent during development. The logging system should be configured to work effectively in both development and production environments.

Testing workflow integration involves setting up automated testing pipelines that run during development and before code commits. The testing configuration should include unit tests for individual functions, integration tests for API endpoints, and end-to-end tests for complete user workflows. Medical applications require particularly thorough testing due to the critical nature of the decisions they support.

Test data management requires careful setup of synthetic datasets that represent realistic medical scenarios while protecting patient privacy. The testing framework should include utilities for generating test patients with various risk profiles and medical conditions. Test data should be versioned and managed consistently across different development environments.

Performance profiling during development involves monitoring application performance, memory usage, and response times. The profiling setup should include tools for analyzing machine learning model performance, database query optimization, and frontend rendering performance. Performance benchmarks should be established for critical operations such as risk assessment calculations and patient data loading.

Code quality monitoring involves setting up automated code analysis, style checking, and security scanning. The development workflow should include pre-commit hooks that run code quality checks and prevent commits that don't meet quality standards. Medical applications require particularly high code quality standards due to the potential impact of software defects.

Continuous integration setup involves configuring automated builds, tests, and deployments that run when code changes are pushed to the repository. The CI pipeline should include steps for testing both the backend and frontend components, running security scans, and generating deployment artifacts. The pipeline should be configured to handle the large model files and datasets that are part of the application.

Documentation workflow involves setting up automated documentation generation and maintenance processes. The development environment should include tools for generating API documentation from code comments and maintaining up-to-date user documentation. Medical applications require comprehensive documentation for regulatory compliance and user training purposes.

Collaboration workflow configuration involves setting up shared development environments, code review processes, and communication tools. The development environment should support multiple developers working on different components simultaneously while maintaining code quality and consistency. Version control workflows should be configured to handle the large files and complex dependencies that are part of medical AI applications.


## Common Issues and Troubleshooting

Developing medical AI applications presents unique challenges that require specific troubleshooting approaches and solutions. Understanding common issues and their resolutions can significantly reduce development time and improve the reliability of the Surgical Risk Assessment MVP. This section provides comprehensive guidance for identifying and resolving the most frequently encountered problems during local development.

Python environment issues often manifest as import errors, version conflicts, or missing dependencies. The most common problem occurs when the Python interpreter cannot locate the project modules or when different versions of scientific computing libraries create compatibility issues. To resolve these issues, ensure that the virtual environment is properly activated and that the PYTHONPATH includes the project root directory. Version conflicts between NumPy, Pandas, and XGBoost can be particularly problematic, requiring careful dependency resolution and sometimes manual installation of compatible versions.

Machine learning model loading errors frequently occur due to version mismatches between the training environment and the deployment environment. XGBoost models are particularly sensitive to version differences, and models trained with one version may not load properly with a different version. To troubleshoot these issues, verify that the XGBoost version matches the version used during model training, and check that all required dependencies are installed with compatible versions. Model file corruption can also cause loading errors, requiring regeneration of the model files.

Database connection issues in the Flask backend often stem from incorrect configuration or missing database files. SQLite database files may not be created automatically in some environments, requiring manual database initialization. Connection string formatting errors can also prevent proper database access. To resolve these issues, verify that the database configuration matches the environment settings and that the database files have proper permissions.

API communication problems between the frontend and backend frequently involve CORS configuration, network connectivity, or request formatting issues. CORS errors are particularly common during development when the frontend and backend run on different ports. Ensure that the Flask backend includes proper CORS headers and that the frontend is configured to make requests to the correct backend URL. Network timeout issues may require adjusting request timeout settings or implementing retry mechanisms.

React component rendering issues often involve state management problems, prop passing errors, or lifecycle method conflicts. State updates that don't trigger re-renders can be particularly frustrating to debug. Use React Developer Tools to inspect component state and props, and verify that state updates are being called correctly. Memory leaks in React components can cause performance degradation over time, requiring careful cleanup of event listeners and subscriptions.

Build and deployment issues frequently involve missing dependencies, configuration errors, or environment-specific problems. Node.js version incompatibilities can cause build failures, requiring verification that the correct Node.js version is installed and active. Missing environment variables can cause runtime errors, requiring careful verification of environment configuration.

Performance issues in medical applications can have serious implications for user experience and clinical workflow. Slow model inference times may indicate memory constraints or inefficient data processing. Monitor memory usage during model loading and inference to identify bottlenecks. Database query performance can be improved through proper indexing and query optimization. Frontend performance issues often involve inefficient rendering or large bundle sizes that can be addressed through code splitting and optimization.

Security-related issues require immediate attention in medical applications. Input validation errors can lead to security vulnerabilities or data corruption. Ensure that all user inputs are properly validated and sanitized before processing. Authentication and authorization issues can prevent proper access control, requiring careful verification of security configurations.

Data handling issues specific to medical applications include validation errors, format inconsistencies, and privacy concerns. Patient data validation should be comprehensive and include checks for medical validity as well as technical correctness. Data format inconsistencies between different components can cause processing errors, requiring standardized data schemas and transformation utilities.

## Step-by-Step Setup Instructions

**Step 1: Environment Preparation**
```bash
# Install Python 3.11+
python --version  # Verify Python 3.11+

# Install Node.js 18+
node --version    # Verify Node.js 18+

# Install Git and Git LFS
git --version
git lfs --version
```

**Step 2: Project Cloning and Setup**
```bash
# Clone the project
git clone <repository-url>
cd surgical-risk-mvp

# Set up Git LFS for large files
git lfs track "*.pkl"
git lfs track "*.joblib"
git lfs track "*.h5"
```

**Step 3: Backend Environment Setup**
```bash
# Navigate to backend directory
cd backend/surgical-risk-api

# Create virtual environment
python -m venv venv

# Activate virtual environment (Windows)
venv\Scripts\activate

# Activate virtual environment (macOS/Linux)
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Initialize database
python src/main.py
```

**Step 4: Frontend Environment Setup**
```bash
# Navigate to frontend directory
cd ../../frontend/surgical-risk-ui

# Install dependencies
npm install

# Start development server
npm run dev
```

**Step 5: VS Code Workspace Configuration**
Create `.vscode/settings.json`:
```json
{
    "python.defaultInterpreterPath": "./backend/surgical-risk-api/venv/bin/python",
    "python.terminal.activateEnvironment": true,
    "eslint.workingDirectories": ["frontend/surgical-risk-ui"],
    "prettier.configPath": "./frontend/surgical-risk-ui/.prettierrc"
}
```

**Step 6: Launch Configuration**
Create `.vscode/launch.json`:
```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Flask Backend",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/backend/surgical-risk-api/src/main.py",
            "env": {
                "FLASK_ENV": "development"
            },
            "console": "integratedTerminal"
        },
        {
            "name": "React Frontend",
            "type": "node",
            "request": "launch",
            "cwd": "${workspaceFolder}/frontend/surgical-risk-ui",
            "runtimeExecutable": "npm",
            "runtimeArgs": ["run", "dev"]
        }
    ],
    "compounds": [
        {
            "name": "Full Stack",
            "configurations": ["Flask Backend", "React Frontend"]
        }
    ]
}
```

This comprehensive setup guide provides the foundation for effective local development of the Surgical Risk Assessment MVP using VS Code. The configuration ensures optimal development experience while maintaining the quality and reliability standards required for medical applications.

