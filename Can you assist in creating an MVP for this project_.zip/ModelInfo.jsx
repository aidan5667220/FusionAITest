import { useState, useEffect } from 'react'
import { 
  Info, 
  Brain, 
  BarChart3, 
  Shield, 
  Database,
  CheckCircle,
  AlertCircle,
  TrendingUp
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'

const ModelInfo = () => {
  const [modelInfo, setModelInfo] = useState(null)
  const [riskBands, setRiskBands] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchModelInfo()
  }, [])

  const fetchModelInfo = async () => {
    try {
      // Fetch model info
      const modelResponse = await fetch('/api/risk/model-info')
      if (modelResponse.ok) {
        const modelData = await modelResponse.json()
        setModelInfo(modelData)
      }

      // Fetch risk bands
      const bandsResponse = await fetch('/api/risk/risk-bands')
      if (bandsResponse.ok) {
        const bandsData = await bandsResponse.json()
        setRiskBands(bandsData)
      }
    } catch (error) {
      console.error('Error fetching model info:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-500">Loading model information...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 flex items-center">
          <Info className="h-6 w-6 mr-2" />
          Model Information
        </h2>
        <p className="text-gray-600">Technical details about the surgical risk assessment system</p>
      </div>

      {/* Model Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Brain className="h-5 w-5 mr-2" />
            Model Overview
          </CardTitle>
          <CardDescription>
            Core machine learning model specifications
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Algorithm</h4>
              <p className="text-sm text-gray-600">
                {modelInfo?.algorithm || 'XGBoost with Isotonic Calibration'}
              </p>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Features</h4>
              <p className="text-sm text-gray-600">
                {modelInfo?.features || '71'} clinical features
              </p>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Version</h4>
              <Badge variant="outline">{modelInfo?.version || '1.0'}</Badge>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Training Date</h4>
              <p className="text-sm text-gray-600">
                {modelInfo?.training_date || 'January 2025'}
              </p>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-gray-900 mb-2">Description</h4>
            <p className="text-sm text-gray-600">
              {modelInfo?.description || 'Advanced machine learning model for surgical risk assessment using evidence-based clinical features and validated risk stratification tools.'}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Performance Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="h-5 w-5 mr-2" />
            Performance Metrics
          </CardTitle>
          <CardDescription>
            Model validation and accuracy statistics
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-1">
                {modelInfo?.performance?.validation_auc ? 
                  (modelInfo.performance.validation_auc * 100).toFixed(1) + '%' : 
                  '82.6%'
                }
              </div>
              <p className="text-sm text-gray-600">AUC Score</p>
              <Progress value={modelInfo?.performance?.validation_auc ? modelInfo.performance.validation_auc * 100 : 82.6} className="mt-2" />
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-1">
                {modelInfo?.performance?.brier_score ? 
                  modelInfo.performance.brier_score.toFixed(3) : 
                  '0.177'
                }
              </div>
              <p className="text-sm text-gray-600">Brier Score</p>
              <p className="text-xs text-gray-500 mt-1">Lower is better</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-1">
                {modelInfo?.performance?.mean_risk_score ? 
                  modelInfo.performance.mean_risk_score.toFixed(1) : 
                  '36.0'
                }
              </div>
              <p className="text-sm text-gray-600">Mean Risk Score</p>
              <p className="text-xs text-gray-500 mt-1">Validation set</p>
            </div>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center">
              <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
              <span className="font-medium text-green-800">Model Performance</span>
            </div>
            <p className="text-sm text-green-700 mt-1">
              The model exceeds the target AUC of 0.82 specified in clinical validation requirements.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Risk Band Definitions */}
      {riskBands && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2" />
              Risk Band Definitions
            </CardTitle>
            <CardDescription>
              Clinical interpretation of risk scores
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(riskBands).map(([band, info]) => (
                <div key={band} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Badge 
                      style={{ backgroundColor: info.color, color: 'white' }}
                      className="min-w-[100px] justify-center"
                    >
                      {band}
                    </Badge>
                    <div>
                      <p className="font-medium text-gray-900">Score: {info.range}</p>
                      <p className="text-sm text-gray-600">{info.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Data Sources */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Database className="h-5 w-5 mr-2" />
            Data Sources & Features
          </CardTitle>
          <CardDescription>
            Clinical data used for risk assessment
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-900 mb-3">Patient Demographics</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Age, sex, BMI</li>
                <li>• Height and weight</li>
                <li>• Medical history</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-3">Laboratory Values</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Creatinine, hemoglobin</li>
                <li>• Electrolytes (Na, K)</li>
                <li>• Liver function (ALT)</li>
                <li>• Coagulation (INR)</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-3">Vital Signs</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Blood pressure</li>
                <li>• Heart rate</li>
                <li>• Oxygen saturation</li>
                <li>• Temperature</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-3">Surgical Factors</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• ASA physical status</li>
                <li>• Procedure complexity</li>
                <li>• Emergency vs elective</li>
                <li>• Procedure duration</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="h-5 w-5 mr-2" />
            System Information
          </CardTitle>
          <CardDescription>
            Platform details and compliance
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Platform</h4>
              <p className="text-sm text-gray-600">Fusion Medical Surgical Risk Assessment</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Environment</h4>
              <Badge variant="outline">MVP Demo</Badge>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-blue-600 mr-2" />
              <span className="font-medium text-blue-800">Important Notice</span>
            </div>
            <p className="text-sm text-blue-700 mt-1">
              This is a demonstration system using synthetic data. Not intended for clinical use. 
              Real implementation would require HIPAA compliance, clinical validation, and regulatory approval.
            </p>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 mb-2">Evidence Base</h4>
            <p className="text-sm text-gray-600">
              Risk assessments are based on established medical guidelines including ASA Physical Status Classification, 
              Revised Cardiac Risk Index (RCRI), and evidence-based perioperative risk stratification tools.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default ModelInfo

