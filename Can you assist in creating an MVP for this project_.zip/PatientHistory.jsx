import { useState } from 'react'
import { History, Search, Eye, Calendar, User, Activity } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

const PatientHistory = ({ assessmentHistory, setCurrentPatient }) => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedAssessment, setSelectedAssessment] = useState(null)

  const getRiskBadgeColor = (riskScore) => {
    if (riskScore <= 20) return 'bg-green-100 text-green-800 border-green-200'
    if (riskScore <= 40) return 'bg-blue-100 text-blue-800 border-blue-200'
    if (riskScore <= 60) return 'bg-yellow-100 text-yellow-800 border-yellow-200'
    if (riskScore <= 80) return 'bg-red-100 text-red-800 border-red-200'
    return 'bg-red-200 text-red-900 border-red-300'
  }

  const filteredHistory = assessmentHistory.filter(assessment =>
    assessment.patient_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    assessment.risk_assessment?.risk_band?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const formatDate = (dateString) => {
    try {
      return new Date(dateString).toLocaleString()
    } catch {
      return 'Unknown date'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <History className="h-6 w-6 mr-2" />
            Assessment History
          </h2>
          <p className="text-gray-600">Review previous risk assessments</p>
        </div>
        <div className="text-sm text-gray-500">
          {assessmentHistory.length} total assessments
        </div>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search by patient ID or risk band..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* History List */}
      {filteredHistory.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <History className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {assessmentHistory.length === 0 ? 'No Assessments Yet' : 'No Matching Results'}
            </h3>
            <p className="text-gray-500">
              {assessmentHistory.length === 0 
                ? 'Start by performing your first risk assessment'
                : 'Try adjusting your search terms'
              }
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredHistory.map((assessment, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <User className="h-6 w-6 text-blue-600" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">
                        {assessment.patient_id || 'Unknown Patient'}
                      </h3>
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <Calendar className="h-3 w-3" />
                        <span>{formatDate(assessment.timestamp)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <div className="text-right">
                      <div className="text-2xl font-bold text-gray-900">
                        {assessment.risk_assessment?.risk_score || 'N/A'}
                      </div>
                      <Badge className={getRiskBadgeColor(assessment.risk_assessment?.risk_score || 0)}>
                        {assessment.risk_assessment?.risk_band || 'UNKNOWN'}
                      </Badge>
                    </div>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setSelectedAssessment(assessment)}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle className="flex items-center">
                            <Activity className="h-5 w-5 mr-2" />
                            Risk Assessment Details
                          </DialogTitle>
                          <DialogDescription>
                            Patient: {assessment.patient_id} | {formatDate(assessment.timestamp)}
                          </DialogDescription>
                        </DialogHeader>
                        
                        {selectedAssessment && (
                          <div className="space-y-6">
                            {/* Risk Score */}
                            <div className="text-center p-6 bg-gray-50 rounded-lg">
                              <div className="text-4xl font-bold text-gray-900 mb-2">
                                {selectedAssessment.risk_assessment?.risk_score || 'N/A'}
                              </div>
                              <Badge className={`text-lg px-4 py-2 ${getRiskBadgeColor(selectedAssessment.risk_assessment?.risk_score || 0)}`}>
                                {selectedAssessment.risk_assessment?.risk_band || 'UNKNOWN'} RISK
                              </Badge>
                              <p className="text-sm text-gray-600 mt-2">
                                Risk Probability: {((selectedAssessment.risk_assessment?.risk_probability || 0) * 100).toFixed(1)}%
                              </p>
                            </div>

                            {/* Explanations */}
                            {selectedAssessment.explanations && (
                              <div className="space-y-4">
                                <div>
                                  <h4 className="font-medium text-red-700 mb-2">High-Risk Factors</h4>
                                  <p className="text-sm text-gray-700 bg-red-50 p-3 rounded-lg">
                                    {selectedAssessment.explanations.high_risk_factors}
                                  </p>
                                </div>

                                <div>
                                  <h4 className="font-medium text-green-700 mb-2">Protective Factors</h4>
                                  <p className="text-sm text-gray-700 bg-green-50 p-3 rounded-lg">
                                    {selectedAssessment.explanations.low_risk_factors}
                                  </p>
                                </div>

                                <div>
                                  <h4 className="font-medium text-blue-700 mb-2">Overall Assessment</h4>
                                  <p className="text-sm text-gray-700 bg-blue-50 p-3 rounded-lg">
                                    {selectedAssessment.explanations.overall_assessment}
                                  </p>
                                </div>
                              </div>
                            )}

                            {/* Guidelines Used */}
                            <div className="text-center text-sm text-gray-500 border-t pt-4">
                              Assessment based on {selectedAssessment.guidelines_used || 0} medical guidelines
                            </div>
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Summary Stats */}
      {assessmentHistory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Assessment Summary</CardTitle>
            <CardDescription>Overview of all risk assessments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {['LOW', 'MODERATE', 'ELEVATED', 'HIGH', 'VERY HIGH'].map(band => {
                const count = assessmentHistory.filter(a => a.risk_assessment?.risk_band === band).length
                const percentage = assessmentHistory.length > 0 ? (count / assessmentHistory.length * 100).toFixed(1) : 0
                
                return (
                  <div key={band} className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{count}</div>
                    <div className="text-sm text-gray-500">{band}</div>
                    <div className="text-xs text-gray-400">{percentage}%</div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default PatientHistory

