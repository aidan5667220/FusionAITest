import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster } from 'sonner'
import Header from './components/Header'
import Dashboard from './components/Dashboard'
import RiskAssessment from './components/RiskAssessment'
import PatientHistory from './components/PatientHistory'
import ModelInfo from './components/ModelInfo'
import './App.css'

function App() {
  const [currentPatient, setCurrentPatient] = useState(null)
  const [assessmentHistory, setAssessmentHistory] = useState([])

  const addToHistory = (assessment) => {
    setAssessmentHistory(prev => [assessment, ...prev])
  }

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route 
              path="/" 
              element={
                <Dashboard 
                  currentPatient={currentPatient}
                  setCurrentPatient={setCurrentPatient}
                  assessmentHistory={assessmentHistory}
                />
              } 
            />
            <Route 
              path="/assess" 
              element={
                <RiskAssessment 
                  currentPatient={currentPatient}
                  setCurrentPatient={setCurrentPatient}
                  addToHistory={addToHistory}
                />
              } 
            />
            <Route 
              path="/history" 
              element={
                <PatientHistory 
                  assessmentHistory={assessmentHistory}
                  setCurrentPatient={setCurrentPatient}
                />
              } 
            />
            <Route path="/model" element={<ModelInfo />} />
          </Routes>
        </main>
        <Toaster />
      </div>
    </Router>
  )
}

export default App

