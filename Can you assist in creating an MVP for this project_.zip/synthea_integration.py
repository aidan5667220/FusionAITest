"""
Synthea Integration API Routes
Surgical Risk Assessment MVP - Fusion Medical

Flask blueprint for handling Synthea FHIR data integration endpoints.

Author: Manus AI
Date: January 2025
Version: 1.0
"""

import os
import sys
import json
import pandas as pd
from flask import Blueprint, request, jsonify, current_app
from werkzeug.utils import secure_filename
import tempfile
from pathlib import Path
import logging

# Add project root to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))

from data.synthea_integration import SyntheaFHIRParser, ClinicalFeatureExtractor, process_synthea_directory

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create blueprint
synthea_bp = Blueprint('synthea', __name__)

# Configuration
ALLOWED_EXTENSIONS = {'json', 'zip'}
MAX_FILE_SIZE = 100 * 1024 * 1024  # 100MB

def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@synthea_bp.route('/upload', methods=['POST'])
def upload_synthea_data():
    """
    Upload and process Synthea FHIR data files.
    
    Accepts either individual FHIR JSON files or ZIP archives containing
    multiple FHIR bundles. Processes the data and returns extracted
    clinical features suitable for surgical risk assessment.
    
    Returns:
        JSON response with processing results and extracted features
    """
    try:
        # Check if file is present in request
        if 'file' not in request.files:
            return jsonify({
                'error': 'No file provided',
                'message': 'Please upload a FHIR JSON file or ZIP archive'
            }), 400
        
        file = request.files['file']
        
        # Check if file is selected
        if file.filename == '':
            return jsonify({
                'error': 'No file selected',
                'message': 'Please select a file to upload'
            }), 400
        
        # Validate file
        if not allowed_file(file.filename):
            return jsonify({
                'error': 'Invalid file type',
                'message': 'Only JSON and ZIP files are allowed'
            }), 400
        
        # Check file size
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > MAX_FILE_SIZE:
            return jsonify({
                'error': 'File too large',
                'message': f'File size exceeds {MAX_FILE_SIZE // (1024*1024)}MB limit'
            }), 400
        
        # Create temporary directory for processing
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Save uploaded file
            filename = secure_filename(file.filename)
            file_path = temp_path / filename
            file.save(str(file_path))
            
            # Process based on file type
            if filename.lower().endswith('.json'):
                # Single FHIR bundle
                processed_data = process_single_bundle(str(file_path))
            elif filename.lower().endswith('.zip'):
                # ZIP archive with multiple bundles
                processed_data = process_zip_archive(str(file_path), temp_dir)
            else:
                return jsonify({
                    'error': 'Unsupported file format',
                    'message': 'Only JSON and ZIP files are supported'
                }), 400
            
            # Return processing results
            return jsonify({
                'success': True,
                'message': f'Successfully processed {len(processed_data)} patients',
                'data': {
                    'patient_count': len(processed_data),
                    'features_extracted': list(processed_data.columns) if not processed_data.empty else [],
                    'sample_data': processed_data.head(5).to_dict('records') if not processed_data.empty else [],
                    'summary_statistics': get_data_summary(processed_data)
                }
            })
            
    except Exception as e:
        logger.error(f"Error processing Synthea upload: {str(e)}")
        return jsonify({
            'error': 'Processing failed',
            'message': str(e)
        }), 500

@synthea_bp.route('/process-directory', methods=['POST'])
def process_directory():
    """
    Process Synthea data from a local directory.
    
    Expects JSON payload with directory path containing FHIR bundles.
    Useful for processing large datasets stored locally.
    
    Returns:
        JSON response with processing results
    """
    try:
        data = request.get_json()
        
        if not data or 'directory_path' not in data:
            return jsonify({
                'error': 'Missing directory path',
                'message': 'Please provide directory_path in request body'
            }), 400
        
        directory_path = data['directory_path']
        
        # Validate directory exists
        if not os.path.exists(directory_path):
            return jsonify({
                'error': 'Directory not found',
                'message': f'Directory {directory_path} does not exist'
            }), 400
        
        # Create output file path
        output_file = data.get('output_file', 'processed_synthea_data.csv')
        
        # Process directory
        processed_data = process_synthea_directory(directory_path, output_file)
        
        return jsonify({
            'success': True,
            'message': f'Successfully processed {len(processed_data)} patients',
            'data': {
                'patient_count': len(processed_data),
                'output_file': output_file,
                'features_extracted': list(processed_data.columns),
                'summary_statistics': get_data_summary(processed_data)
            }
        })
        
    except Exception as e:
        logger.error(f"Error processing directory: {str(e)}")
        return jsonify({
            'error': 'Processing failed',
            'message': str(e)
        }), 500

@synthea_bp.route('/validate-fhir', methods=['POST'])
def validate_fhir():
    """
    Validate FHIR bundle structure and content.
    
    Accepts FHIR JSON data and validates it against FHIR specifications
    and clinical requirements for surgical risk assessment.
    
    Returns:
        JSON response with validation results
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({
                'error': 'No data provided',
                'message': 'Please provide FHIR bundle data'
            }), 400
        
        # Initialize parser for validation
        parser = SyntheaFHIRParser()
        
        # Validate bundle structure
        validation_results = validate_bundle_structure(data, parser)
        
        return jsonify({
            'success': True,
            'validation_results': validation_results
        })
        
    except Exception as e:
        logger.error(f"Error validating FHIR data: {str(e)}")
        return jsonify({
            'error': 'Validation failed',
            'message': str(e)
        }), 500

@synthea_bp.route('/feature-mapping', methods=['GET'])
def get_feature_mapping():
    """
    Get information about clinical feature mapping.
    
    Returns details about how FHIR resources are mapped to
    clinical features for surgical risk assessment.
    
    Returns:
        JSON response with feature mapping information
    """
    try:
        parser = SyntheaFHIRParser()
        extractor = ClinicalFeatureExtractor(parser)
        
        mapping_info = {
            'icd10_mappings': parser.icd10_to_comorbidity,
            'loinc_mappings': parser.loinc_to_feature,
            'snomed_mappings': parser.snomed_to_category,
            'feature_categories': extractor.feature_definitions,
            'supported_resources': [
                'Patient', 'Condition', 'Observation', 
                'Procedure', 'MedicationStatement', 'Encounter'
            ]
        }
        
        return jsonify({
            'success': True,
            'mapping_info': mapping_info
        })
        
    except Exception as e:
        logger.error(f"Error getting feature mapping: {str(e)}")
        return jsonify({
            'error': 'Failed to get mapping info',
            'message': str(e)
        }), 500

@synthea_bp.route('/generate-sample', methods=['POST'])
def generate_sample_data():
    """
    Generate sample synthetic patient data for testing.
    
    Creates a small set of synthetic patients with realistic
    clinical features for testing the risk assessment system.
    
    Returns:
        JSON response with generated sample data
    """
    try:
        data = request.get_json() or {}
        patient_count = data.get('patient_count', 10)
        
        if patient_count > 100:
            return jsonify({
                'error': 'Too many patients requested',
                'message': 'Maximum 100 patients allowed for sample generation'
            }), 400
        
        # Generate sample data
        sample_data = generate_synthetic_patients(patient_count)
        
        return jsonify({
            'success': True,
            'message': f'Generated {len(sample_data)} sample patients',
            'data': {
                'patient_count': len(sample_data),
                'sample_patients': sample_data
            }
        })
        
    except Exception as e:
        logger.error(f"Error generating sample data: {str(e)}")
        return jsonify({
            'error': 'Sample generation failed',
            'message': str(e)
        }), 500

def process_single_bundle(file_path: str) -> pd.DataFrame:
    """Process a single FHIR bundle file."""
    parser = SyntheaFHIRParser()
    extractor = ClinicalFeatureExtractor(parser)
    
    # Parse FHIR bundle
    resources = parser.parse_fhir_bundle(file_path)
    
    all_features = []
    
    # Process each patient
    for patient in resources['patients']:
        patient_id = patient['patient_id']
        
        # Get related resources
        patient_conditions = [c for c in resources['conditions'] 
                            if c['patient_id'] == patient_id]
        patient_observations = [o for o in resources['observations'] 
                              if o['patient_id'] == patient_id]
        patient_procedures = [p for p in resources['procedures'] 
                            if p['patient_id'] == patient_id]
        patient_medications = [m for m in resources['medications'] 
                             if m['patient_id'] == patient_id]
        
        # Extract features
        features = extractor.extract_patient_features(
            patient, patient_conditions, patient_observations,
            patient_procedures, patient_medications
        )
        
        features['patient_id'] = patient_id
        all_features.append(features)
    
    return pd.DataFrame(all_features)

def process_zip_archive(zip_path: str, temp_dir: str) -> pd.DataFrame:
    """Process a ZIP archive containing multiple FHIR bundles."""
    import zipfile
    
    # Extract ZIP file
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(temp_dir)
    
    # Find JSON files in extracted content
    extracted_path = Path(temp_dir)
    json_files = list(extracted_path.rglob('*.json'))
    
    if not json_files:
        raise ValueError("No JSON files found in ZIP archive")
    
    # Process all JSON files
    all_data = []
    
    for json_file in json_files:
        try:
            bundle_data = process_single_bundle(str(json_file))
            all_data.append(bundle_data)
        except Exception as e:
            logger.warning(f"Failed to process {json_file}: {str(e)}")
            continue
    
    # Combine all data
    if all_data:
        return pd.concat(all_data, ignore_index=True)
    else:
        return pd.DataFrame()

def validate_bundle_structure(bundle_data: dict, parser: SyntheaFHIRParser) -> dict:
    """Validate FHIR bundle structure and content."""
    validation_results = {
        'is_valid_bundle': False,
        'resource_counts': {},
        'validation_errors': [],
        'clinical_completeness': {}
    }
    
    try:
        # Check if it's a valid FHIR bundle
        if bundle_data.get('resourceType') != 'Bundle':
            validation_results['validation_errors'].append(
                "Not a valid FHIR Bundle resource"
            )
            return validation_results
        
        validation_results['is_valid_bundle'] = True
        
        # Count resources by type
        resource_counts = {}
        entries = bundle_data.get('entry', [])
        
        for entry in entries:
            resource = entry.get('resource', {})
            resource_type = resource.get('resourceType')
            
            if resource_type:
                resource_counts[resource_type] = resource_counts.get(resource_type, 0) + 1
        
        validation_results['resource_counts'] = resource_counts
        
        # Check clinical completeness
        validation_results['clinical_completeness'] = {
            'has_patients': resource_counts.get('Patient', 0) > 0,
            'has_conditions': resource_counts.get('Condition', 0) > 0,
            'has_observations': resource_counts.get('Observation', 0) > 0,
            'has_procedures': resource_counts.get('Procedure', 0) > 0,
            'has_medications': resource_counts.get('MedicationStatement', 0) > 0
        }
        
        # Check for required clinical data
        if not validation_results['clinical_completeness']['has_patients']:
            validation_results['validation_errors'].append(
                "No Patient resources found"
            )
        
        if not validation_results['clinical_completeness']['has_observations']:
            validation_results['validation_errors'].append(
                "No Observation resources found - lab values and vitals needed"
            )
        
    except Exception as e:
        validation_results['validation_errors'].append(f"Validation error: {str(e)}")
    
    return validation_results

def get_data_summary(df: pd.DataFrame) -> dict:
    """Generate summary statistics for processed data."""
    if df.empty:
        return {}
    
    summary = {
        'total_patients': len(df),
        'age_statistics': {
            'mean': float(df['age'].mean()) if 'age' in df else None,
            'min': float(df['age'].min()) if 'age' in df else None,
            'max': float(df['age'].max()) if 'age' in df else None
        },
        'gender_distribution': {
            'male': int(df['sex_male'].sum()) if 'sex_male' in df else 0,
            'female': int(df['sex_female'].sum()) if 'sex_female' in df else 0
        },
        'comorbidity_prevalence': {},
        'data_completeness': {}
    }
    
    # Calculate comorbidity prevalence
    comorbidity_columns = ['diabetes', 'hypertension', 'coronary_artery_disease',
                          'congestive_heart_failure', 'chronic_kidney_disease', 'copd']
    
    for col in comorbidity_columns:
        if col in df:
            summary['comorbidity_prevalence'][col] = float(df[col].mean())
    
    # Calculate data completeness
    for col in df.columns:
        if col not in ['patient_id', 'source_file']:
            completeness = (df[col].notna().sum() / len(df)) * 100
            summary['data_completeness'][col] = float(completeness)
    
    return summary

def generate_synthetic_patients(count: int) -> list:
    """Generate sample synthetic patient data for testing."""
    import random
    from datetime import datetime, timedelta
    
    patients = []
    
    for i in range(count):
        # Generate random patient data
        age = random.randint(18, 90)
        gender = random.choice(['male', 'female'])
        
        patient = {
            'patient_id': f'SAMPLE_{i+1:03d}',
            'age': age,
            'sex_male': 1 if gender == 'male' else 0,
            'sex_female': 1 if gender == 'female' else 0,
            'diabetes': random.choice([0, 1]) if age > 40 else 0,
            'hypertension': random.choice([0, 1]) if age > 30 else 0,
            'coronary_artery_disease': random.choice([0, 1]) if age > 50 else 0,
            'bmi': round(random.uniform(18.5, 35.0), 1),
            'hemoglobin': round(random.uniform(10.0, 16.0), 1),
            'creatinine': round(random.uniform(0.6, 2.0), 2),
            'systolic_bp': random.randint(90, 180),
            'diastolic_bp': random.randint(60, 110),
            'heart_rate': random.randint(60, 100),
            'estimated_asa_class': random.randint(1, 4)
        }
        
        patients.append(patient)
    
    return patients

# Error handlers
@synthea_bp.errorhandler(413)
def too_large(e):
    """Handle file too large error."""
    return jsonify({
        'error': 'File too large',
        'message': 'Uploaded file exceeds size limit'
    }), 413

@synthea_bp.errorhandler(400)
def bad_request(e):
    """Handle bad request error."""
    return jsonify({
        'error': 'Bad request',
        'message': 'Invalid request format or parameters'
    }), 400

