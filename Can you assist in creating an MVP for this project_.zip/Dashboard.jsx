import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { 
  Activity, 
  Users, 
  TrendingUp, 
  AlertTriangle, 
  Plus,
  Clock,
  CheckCircle,
  XCircle
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const Dashboard = ({ currentPatient, setCurrentPatient, assessmentHistory }) => {
  const [demoPatients, setDemoPatients] = useState([])
  const [modelInfo, setModelInfo] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      // Fetch demo patients
      const demoResponse = await fetch('/api/risk/demo-patients')
      if (demoResponse.ok) {
        const demoData = await demoResponse.json()
        setDemoPatients(demoData.demo_patients || [])
      }

      // Fetch model info
      const modelResponse = await fetch('/api/risk/model-info')
      if (modelResponse.ok) {
        const modelData = await modelResponse.json()
        setModelInfo(modelData)
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getRiskBadgeColor = (riskScore) => {
    if (riskScore <= 20) return 'bg-green-100 text-green-800'
    if (riskScore <= 40) return 'bg-blue-100 text-blue-800'
    if (riskScore <= 60) return 'bg-yellow-100 text-yellow-800'
    if (riskScore <= 80) return 'bg-red-100 text-red-800'
    return 'bg-red-200 text-red-900'
  }

  const getRiskBand = (riskScore) => {
    if (riskScore <= 20) return 'LOW'
    if (riskScore <= 40) return 'MODERATE'
    if (riskScore <= 60) return 'ELEVATED'
    if (riskScore <= 80) return 'HIGH'
    return 'VERY HIGH'
  }

  const recentAssessments = assessmentHistory.slice(0, 5)

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              Welcome to Surgical Risk Assessment
            </h2>
            <p className="text-gray-600 mt-2">
              AI-powered surgical risk evaluation with evidence-based explanations
            </p>
          </div>
          <Link to="/assess">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              New Assessment
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Assessments</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{assessmentHistory.length}</div>
            <p className="text-xs text-muted-foreground">
              Risk assessments completed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Model Accuracy</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {modelInfo?.performance?.validation_auc ? 
                (modelInfo.performance.validation_auc * 100).toFixed(1) + '%' : 
                '82.6%'
              }
            </div>
            <p className="text-xs text-muted-foreground">
              AUC validation score
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">High Risk Cases</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {assessmentHistory.filter(a => a.risk_assessment?.risk_score > 60).length}
            </div>
            <p className="text-xs text-muted-foreground">
              Requiring intensive care
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Demo Patients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{demoPatients.length}</div>
            <p className="text-xs text-muted-foreground">
              Available for testing
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Assessments */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="h-5 w-5 mr-2" />
              Recent Assessments
            </CardTitle>
            <CardDescription>
              Latest risk evaluations performed
            </CardDescription>
          </CardHeader>
          <CardContent>
            {recentAssessments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No assessments yet</p>
                <p className="text-sm">Start by creating your first risk assessment</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentAssessments.map((assessment, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="flex-shrink-0">
                        {assessment.risk_assessment?.risk_score > 60 ? (
                          <XCircle className="h-5 w-5 text-red-500" />
                        ) : (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-sm">
                          {assessment.patient_id || 'Unknown Patient'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(assessment.timestamp).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <Badge className={getRiskBadgeColor(assessment.risk_assessment?.risk_score || 0)}>
                      {getRiskBand(assessment.risk_assessment?.risk_score || 0)} ({assessment.risk_assessment?.risk_score || 0})
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Demo Patients */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2" />
              Demo Patients
            </CardTitle>
            <CardDescription>
              Pre-loaded patients for testing the system
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="text-sm text-gray-500 mt-2">Loading demo patients...</p>
              </div>
            ) : demoPatients.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No demo patients available</p>
              </div>
            ) : (
              <div className="space-y-3">
                {demoPatients.slice(0, 5).map((patient, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">
                        {patient.age}yr {patient.sex}, BMI {patient.bmi}
                      </p>
                      <p className="text-xs text-gray-500">
                        {patient.procedure} (ASA {patient.asa_class})
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getRiskBadgeColor(patient.true_risk_score)}>
                        {patient.true_risk_score}
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setCurrentPatient(patient.full_data)
                        }}
                      >
                        Load
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Current Patient */}
      {currentPatient && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="h-5 w-5 mr-2" />
              Current Patient
            </CardTitle>
            <CardDescription>
              Patient loaded and ready for assessment
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">
                  {currentPatient.age}-year-old {currentPatient.sex}, BMI {currentPatient.bmi}
                </p>
                <p className="text-sm text-gray-500">
                  {currentPatient.surgical_details?.procedure_name} 
                  (ASA Class {currentPatient.surgical_details?.asa_class})
                </p>
              </div>
              <Link to="/assess">
                <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                  Assess Risk
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default Dashboard

