"""
RAG (Retrieval-Augmented Generation) System for Surgical Risk Assessment
Implements vector database storage and retrieval of medical guidelines.
"""

import os
import json
import pickle
import numpy as np
import faiss
from typing import List, Dict, Any, Tuple
import tiktoken
from openai import OpenAI
import re
from pathlib import Path

class MedicalRAGSystem:
    def __init__(self, embedding_model: str = "text-embedding-3-small"):
        """Initialize the RAG system."""
        self.client = OpenAI()
        self.embedding_model = embedding_model
        self.embedding_dim = 1536  # Dimension for text-embedding-3-small
        self.index = None
        self.chunks = []
        self.chunk_metadata = []
        self.tokenizer = tiktoken.get_encoding("cl100k_base")
        
        # Chunk parameters
        self.chunk_size = 500  # tokens per chunk
        self.chunk_overlap = 50  # token overlap between chunks
        
    def chunk_text(self, text: str, source: str = "unknown") -> List[Dict[str, Any]]:
        """Split text into overlapping chunks."""
        # Clean and normalize text
        text = re.sub(r'\n+', '\n', text)
        text = re.sub(r'\s+', ' ', text)
        
        # Tokenize the text
        tokens = self.tokenizer.encode(text)
        
        chunks = []
        start_idx = 0
        
        while start_idx < len(tokens):
            # Define chunk boundaries
            end_idx = min(start_idx + self.chunk_size, len(tokens))
            
            # Extract chunk tokens
            chunk_tokens = tokens[start_idx:end_idx]
            chunk_text = self.tokenizer.decode(chunk_tokens)
            
            # Create chunk metadata
            chunk_data = {
                'text': chunk_text.strip(),
                'source': source,
                'start_token': start_idx,
                'end_token': end_idx,
                'token_count': len(chunk_tokens),
                'chunk_id': len(chunks)
            }
            
            chunks.append(chunk_data)
            
            # Move to next chunk with overlap
            start_idx += self.chunk_size - self.chunk_overlap
            
            # Break if we've reached the end
            if end_idx >= len(tokens):
                break
        
        return chunks

    def create_embeddings(self, texts: List[str]) -> np.ndarray:
        """Create embeddings for a list of texts."""
        print(f"Creating embeddings for {len(texts)} text chunks...")
        
        embeddings = []
        batch_size = 100  # Process in batches to avoid rate limits
        
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i + batch_size]
            
            try:
                response = self.client.embeddings.create(
                    model=self.embedding_model,
                    input=batch_texts
                )
                
                batch_embeddings = [item.embedding for item in response.data]
                embeddings.extend(batch_embeddings)
                
                print(f"  Processed {min(i + batch_size, len(texts))}/{len(texts)} chunks")
                
            except Exception as e:
                print(f"Error creating embeddings for batch {i}: {e}")
                # Create zero embeddings as fallback
                batch_embeddings = [[0.0] * self.embedding_dim] * len(batch_texts)
                embeddings.extend(batch_embeddings)
        
        return np.array(embeddings, dtype=np.float32)

    def build_index(self, documents: List[Dict[str, str]]) -> None:
        """Build the vector index from documents."""
        print("Building vector index from documents...")
        
        # Process all documents and create chunks
        all_chunks = []
        for doc in documents:
            doc_chunks = self.chunk_text(doc['content'], doc['source'])
            all_chunks.extend(doc_chunks)
        
        print(f"Created {len(all_chunks)} chunks from {len(documents)} documents")
        
        # Extract text for embedding
        chunk_texts = [chunk['text'] for chunk in all_chunks]
        
        # Create embeddings
        embeddings = self.create_embeddings(chunk_texts)
        
        # Build FAISS index
        self.index = faiss.IndexFlatIP(self.embedding_dim)  # Inner product for cosine similarity
        
        # Normalize embeddings for cosine similarity
        faiss.normalize_L2(embeddings)
        
        # Add embeddings to index
        self.index.add(embeddings)
        
        # Store chunks and metadata
        self.chunks = all_chunks
        self.chunk_metadata = [
            {
                'source': chunk['source'],
                'chunk_id': chunk['chunk_id'],
                'token_count': chunk['token_count']
            }
            for chunk in all_chunks
        ]
        
        print(f"Vector index built with {self.index.ntotal} embeddings")

    def retrieve_relevant_chunks(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Retrieve the most relevant chunks for a query."""
        if self.index is None:
            raise ValueError("Index not built. Call build_index() first.")
        
        # Create query embedding
        query_embedding = self.create_embeddings([query])
        
        # Normalize query embedding
        faiss.normalize_L2(query_embedding)
        
        # Search the index
        scores, indices = self.index.search(query_embedding, top_k)
        
        # Retrieve relevant chunks
        relevant_chunks = []
        for i, (score, idx) in enumerate(zip(scores[0], indices[0])):
            if idx < len(self.chunks):  # Valid index
                chunk_data = self.chunks[idx].copy()
                chunk_data['relevance_score'] = float(score)
                chunk_data['rank'] = i + 1
                relevant_chunks.append(chunk_data)
        
        return relevant_chunks

    def generate_context_from_chunks(self, chunks: List[Dict[str, Any]]) -> str:
        """Generate formatted context from retrieved chunks."""
        if not chunks:
            return "No relevant medical guidelines found."
        
        context_parts = []
        context_parts.append("## Relevant Medical Guidelines\n")
        
        for i, chunk in enumerate(chunks, 1):
            context_parts.append(f"### Guideline {i} (Relevance: {chunk['relevance_score']:.3f})")
            context_parts.append(f"Source: {chunk['source']}")
            context_parts.append(f"{chunk['text']}")
            context_parts.append("")  # Empty line for separation
        
        return "\n".join(context_parts)

    def save_index(self, filepath: str) -> None:
        """Save the vector index and metadata to disk."""
        if self.index is None:
            raise ValueError("No index to save. Build index first.")
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        # Save FAISS index
        index_path = filepath + ".faiss"
        faiss.write_index(self.index, index_path)
        
        # Save metadata
        metadata = {
            'chunks': self.chunks,
            'chunk_metadata': self.chunk_metadata,
            'embedding_model': self.embedding_model,
            'embedding_dim': self.embedding_dim,
            'chunk_size': self.chunk_size,
            'chunk_overlap': self.chunk_overlap
        }
        
        metadata_path = filepath + ".pkl"
        with open(metadata_path, 'wb') as f:
            pickle.dump(metadata, f)
        
        print(f"Index saved to {index_path}")
        print(f"Metadata saved to {metadata_path}")

    def load_index(self, filepath: str) -> None:
        """Load the vector index and metadata from disk."""
        # Load FAISS index
        index_path = filepath + ".faiss"
        if not os.path.exists(index_path):
            raise FileNotFoundError(f"Index file not found: {index_path}")
        
        self.index = faiss.read_index(index_path)
        
        # Load metadata
        metadata_path = filepath + ".pkl"
        if not os.path.exists(metadata_path):
            raise FileNotFoundError(f"Metadata file not found: {metadata_path}")
        
        with open(metadata_path, 'rb') as f:
            metadata = pickle.load(f)
        
        self.chunks = metadata['chunks']
        self.chunk_metadata = metadata['chunk_metadata']
        self.embedding_model = metadata['embedding_model']
        self.embedding_dim = metadata['embedding_dim']
        self.chunk_size = metadata['chunk_size']
        self.chunk_overlap = metadata['chunk_overlap']
        
        print(f"Index loaded from {index_path}")
        print(f"Loaded {len(self.chunks)} chunks")

class SurgicalRiskRAG:
    def __init__(self):
        """Initialize the surgical risk-specific RAG system."""
        self.rag_system = MedicalRAGSystem()
        self.llm_model = "gpt-4o"
        self.client = OpenAI()
        
        # Risk assessment prompt template
        self.system_prompt = """You are a surgical risk assessment AI assistant. Your role is to provide evidence-based explanations for surgical risk scores using medical guidelines and patient data.

When provided with:
1. A patient's risk score and risk band
2. Patient clinical features
3. Relevant medical guidelines

You should generate:
1. An explanation of high-risk factors contributing to the score
2. An explanation of low-risk factors (protective factors)
3. A comprehensive risk assessment narrative

Base your explanations on the provided medical guidelines and use clinical terminology appropriate for healthcare professionals. Be specific about which guidelines support your assessments."""

    def load_medical_guidelines(self) -> None:
        """Load and index medical guidelines."""
        print("Loading medical guidelines...")
        
        # Load the surgical risk guidelines
        guidelines_path = "/home/ubuntu/surgical-risk-mvp/data/guidelines/surgical_risk_guidelines.md"
        
        with open(guidelines_path, 'r') as f:
            guidelines_content = f.read()
        
        # Create document structure
        documents = [
            {
                'source': 'Surgical Risk Assessment Guidelines',
                'content': guidelines_content
            }
        ]
        
        # Build the vector index
        self.rag_system.build_index(documents)
        
        # Save the index
        index_path = "/home/ubuntu/surgical-risk-mvp/vector_db/storage/medical_guidelines_index"
        self.rag_system.save_index(index_path)
        
        print("Medical guidelines loaded and indexed successfully!")

    def generate_risk_explanation(self, patient_data: Dict[str, Any], 
                                risk_prediction: Dict[str, Any]) -> Dict[str, Any]:
        """Generate comprehensive risk explanation using RAG."""
        
        # Create queries for different aspects of risk assessment
        queries = []
        
        # Query based on risk factors
        risk_factors = []
        if patient_data.get('engineered_features', {}).get('high_risk_surgery', False):
            risk_factors.append("high-risk surgery")
        if patient_data.get('surgical_details', {}).get('asa_class', 0) >= 3:
            risk_factors.append("ASA class")
        if patient_data.get('age', 0) >= 70:
            risk_factors.append("elderly patient")
        if patient_data.get('engineered_features', {}).get('heart_failure', False):
            risk_factors.append("heart failure")
        
        if risk_factors:
            queries.append(f"surgical risk factors {' '.join(risk_factors)}")
        
        # Query based on risk band
        risk_band = risk_prediction['risk_band']
        queries.append(f"{risk_band.lower()} risk surgery complications")
        
        # Query for general risk assessment
        queries.append("preoperative risk assessment guidelines")
        
        # Retrieve relevant chunks for all queries
        all_chunks = []
        for query in queries:
            chunks = self.rag_system.retrieve_relevant_chunks(query, top_k=3)
            all_chunks.extend(chunks)
        
        # Remove duplicates and keep top chunks
        seen_chunks = set()
        unique_chunks = []
        for chunk in all_chunks:
            chunk_id = (chunk['source'], chunk['chunk_id'])
            if chunk_id not in seen_chunks:
                seen_chunks.add(chunk_id)
                unique_chunks.append(chunk)
        
        # Sort by relevance and take top 5
        unique_chunks.sort(key=lambda x: x['relevance_score'], reverse=True)
        top_chunks = unique_chunks[:5]
        
        # Generate context from chunks
        context = self.rag_system.generate_context_from_chunks(top_chunks)
        
        # Create patient summary
        patient_summary = self.create_patient_summary(patient_data)
        
        # Generate explanation using LLM
        explanation = self.generate_llm_explanation(
            patient_summary, risk_prediction, context
        )
        
        return {
            'explanation': explanation,
            'retrieved_guidelines': top_chunks,
            'context_used': context
        }

    def create_patient_summary(self, patient_data: Dict[str, Any]) -> str:
        """Create a structured patient summary."""
        summary_parts = []
        
        # Demographics
        age = patient_data.get('age', 'Unknown')
        sex = patient_data.get('sex', 'Unknown')
        bmi = patient_data.get('bmi', 'Unknown')
        summary_parts.append(f"Patient: {age}-year-old {sex}, BMI {bmi}")
        
        # Surgical details
        surgical = patient_data.get('surgical_details', {})
        procedure = surgical.get('procedure_name', 'Unknown procedure')
        asa_class = surgical.get('asa_class', 'Unknown')
        cpt_tier = surgical.get('cpt_invasiveness_tier', 'Unknown')
        summary_parts.append(f"Procedure: {procedure} (ASA Class {asa_class}, CPT Tier {cpt_tier})")
        
        # Key lab values
        labs = patient_data.get('labs', {})
        if labs:
            lab_summary = []
            if 'creatinine' in labs:
                lab_summary.append(f"Creatinine {labs['creatinine']} mg/dL")
            if 'hemoglobin' in labs:
                lab_summary.append(f"Hemoglobin {labs['hemoglobin']} g/dL")
            if 'inr' in labs:
                lab_summary.append(f"INR {labs['inr']}")
            if lab_summary:
                summary_parts.append(f"Labs: {', '.join(lab_summary)}")
        
        # Key conditions
        conditions = patient_data.get('medical_history', {}).get('conditions', [])
        if conditions:
            summary_parts.append(f"Conditions: {', '.join(conditions[:5])}")
        
        # Risk factors
        engineered = patient_data.get('engineered_features', {})
        risk_factors = []
        if engineered.get('recent_mi', False):
            risk_factors.append("Recent MI")
        if engineered.get('heart_failure', False):
            risk_factors.append("Heart failure")
        if engineered.get('bmi_ge40', False):
            risk_factors.append("Severe obesity")
        if engineered.get('creatinine_ge2', False):
            risk_factors.append("Kidney disease")
        
        if risk_factors:
            summary_parts.append(f"Risk factors: {', '.join(risk_factors)}")
        
        return "\n".join(summary_parts)

    def generate_llm_explanation(self, patient_summary: str, 
                                risk_prediction: Dict[str, Any], 
                                context: str) -> Dict[str, str]:
        """Generate explanation using LLM with retrieved context."""
        
        user_prompt = f"""
## Patient Information
{patient_summary}

## Risk Assessment Results
- Risk Score: {risk_prediction['risk_score']} ({risk_prediction['risk_band']})
- Risk Probability: {risk_prediction['risk_probability']:.3f}

## Medical Guidelines Context
{context}

Please provide:
1. **High-risk factors**: Explain the specific factors that contribute to increased surgical risk for this patient
2. **Low-risk factors**: Identify any protective factors or normal findings that may reduce risk
3. **Overall assessment**: Provide a comprehensive narrative risk assessment

Format your response as JSON with keys: "high_risk_factors", "low_risk_factors", "overall_assessment"
"""

        try:
            response = self.client.chat.completions.create(
                model=self.llm_model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.3,
                max_tokens=1000
            )
            
            # Parse JSON response
            content = response.choices[0].message.content
            
            # Try to extract JSON from the response
            try:
                # Look for JSON in the response
                import json
                json_start = content.find('{')
                json_end = content.rfind('}') + 1
                if json_start != -1 and json_end != -1:
                    json_content = content[json_start:json_end]
                    explanation = json.loads(json_content)
                else:
                    # Fallback: create structured response
                    explanation = {
                        "high_risk_factors": content[:300] + "...",
                        "low_risk_factors": "Standard preoperative evaluation completed.",
                        "overall_assessment": content
                    }
            except json.JSONDecodeError:
                # Fallback response
                explanation = {
                    "high_risk_factors": f"Risk score of {risk_prediction['risk_score']} indicates elevated surgical risk based on patient factors.",
                    "low_risk_factors": "Standard preoperative evaluation completed with appropriate risk stratification.",
                    "overall_assessment": content
                }
            
            return explanation
            
        except Exception as e:
            print(f"Error generating LLM explanation: {e}")
            # Fallback explanation
            return {
                "high_risk_factors": f"Risk score of {risk_prediction['risk_score']} ({risk_prediction['risk_band']}) based on clinical assessment.",
                "low_risk_factors": "Standard preoperative evaluation completed.",
                "overall_assessment": f"Patient has {risk_prediction['risk_band'].lower()} surgical risk with score of {risk_prediction['risk_score']}."
            }

def test_rag_system():
    """Test the RAG system functionality."""
    print("Testing RAG System...")
    
    # Initialize RAG system
    rag = SurgicalRiskRAG()
    
    # Load and index guidelines
    rag.load_medical_guidelines()
    
    # Test retrieval
    test_query = "high-risk surgery cardiac complications"
    chunks = rag.rag_system.retrieve_relevant_chunks(test_query, top_k=3)
    
    print(f"\nTest Query: '{test_query}'")
    print(f"Retrieved {len(chunks)} relevant chunks:")
    for i, chunk in enumerate(chunks, 1):
        print(f"{i}. Score: {chunk['relevance_score']:.3f}")
        print(f"   Text: {chunk['text'][:100]}...")
        print()
    
    # Test with sample patient
    sample_patient = {
        'age': 75,
        'sex': 'M',
        'bmi': 32,
        'surgical_details': {
            'procedure_name': 'Cardiac surgery',
            'asa_class': 4,
            'cpt_invasiveness_tier': 4
        },
        'labs': {
            'creatinine': 2.1,
            'hemoglobin': 9.5,
            'inr': 1.8
        },
        'medical_history': {
            'conditions': ['Heart failure', 'Diabetes mellitus type 2', 'Chronic kidney disease']
        },
        'engineered_features': {
            'high_risk_surgery': True,
            'heart_failure': True,
            'creatinine_ge2': True,
            'asa_ge4': True
        }
    }
    
    sample_prediction = {
        'risk_score': 75,
        'risk_band': 'HIGH',
        'risk_probability': 0.75
    }
    
    print("Testing risk explanation generation...")
    explanation_result = rag.generate_risk_explanation(sample_patient, sample_prediction)
    
    print("\nGenerated Explanation:")
    print("High-risk factors:", explanation_result['explanation']['high_risk_factors'])
    print("Low-risk factors:", explanation_result['explanation']['low_risk_factors'])
    print("Overall assessment:", explanation_result['explanation']['overall_assessment'])
    
    print("\nRAG system test completed successfully!")

if __name__ == "__main__":
    # Create storage directory
    os.makedirs('/home/ubuntu/surgical-risk-mvp/vector_db/storage', exist_ok=True)
    
    # Test the RAG system
    test_rag_system()

