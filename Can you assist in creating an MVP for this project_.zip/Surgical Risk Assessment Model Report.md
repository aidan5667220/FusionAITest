# Surgical Risk Assessment Model Report

## Model Performance Metrics
- **Validation AUC**: 0.8263
- **Brier Score**: 0.1766
- **Mean Risk Score**: 36.0

## Model Configuration
- **Algorithm**: XGBoost with Isotonic Calibration
- **Features**: 71
- **Best Parameters**: {'colsample_bytree': 0.8, 'learning_rate': 0.01, 'max_depth': 4, 'n_estimators': 200, 'subsample': 0.8}

## Top 10 Most Important Features
39. High Risk Surgery: 0.0980
46. Cpt Invasiveness Tier 1: 0.0497
43. Risk Factor Count: 0.0433
30. Heart Failure: 0.0425
47. Cpt Invasiveness Tier 2: 0.0365
40. Asa Ge4: 0.0267
48. Cpt Invasiveness Tier 3: 0.0252
45. Sex: M: 0.0228
52. Asa Class 2: 0.0214
50. Cpt Invasiveness Tier 5: 0.0207

## Risk Band Definitions
- **LOW**: 0-20
- **MODERATE**: 21-40
- **ELEVATED**: 41-60
- **HIGH**: 61-80
- **VERY HIGH**: 81-100