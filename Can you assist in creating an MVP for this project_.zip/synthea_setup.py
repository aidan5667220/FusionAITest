#!/usr/bin/env python3
"""
Synthea Setup and Data Generation Script
Surgical Risk Assessment MVP - Fusion Medical

This script helps set up Synthea and generate synthetic patient data
for testing the surgical risk assessment system.

Author: Manus AI
Date: January 2025
Version: 1.0
"""

import os
import sys
import subprocess
import json
import shutil
from pathlib import Path
import argparse
import logging
from typing import Optional

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SyntheaSetup:
    """
    Handles Synthea installation, configuration, and data generation.
    """
    
    def __init__(self, base_dir: str = None):
        """
        Initialize Synthea setup.
        
        Args:
            base_dir: Base directory for Synthea installation
        """
        self.base_dir = Path(base_dir) if base_dir else Path.cwd() / 'synthea'
        self.synthea_dir = self.base_dir / 'synthea'
        self.output_dir = self.base_dir / 'output'
        self.config_dir = self.base_dir / 'config'
        
        # Ensure directories exist
        self.base_dir.mkdir(exist_ok=True)
        self.output_dir.mkdir(exist_ok=True)
        self.config_dir.mkdir(exist_ok=True)
        
        logger.info(f"Synthea setup initialized in: {self.base_dir}")
    
    def check_java_installation(self) -> bool:
        """
        Check if Java is installed and available.
        
        Returns:
            True if Java is available, False otherwise
        """
        try:
            result = subprocess.run(['java', '-version'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                logger.info("Java installation found")
                return True
            else:
                logger.error("Java not found or not working properly")
                return False
        except FileNotFoundError:
            logger.error("Java not found in PATH")
            return False
    
    def download_synthea(self, version: str = "3.2.0") -> bool:
        """
        Download Synthea JAR file.
        
        Args:
            version: Synthea version to download
            
        Returns:
            True if download successful, False otherwise
        """
        try:
            import requests
            
            # Synthea GitHub releases URL
            url = f"https://github.com/synthetichealth/synthea/releases/download/v{version}/synthea-with-dependencies.jar"
            
            jar_path = self.base_dir / f"synthea-{version}.jar"
            
            if jar_path.exists():
                logger.info(f"Synthea JAR already exists: {jar_path}")
                return True
            
            logger.info(f"Downloading Synthea v{version}...")
            
            response = requests.get(url, stream=True)
            response.raise_for_status()
            
            with open(jar_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            # Create symlink for easy access
            symlink_path = self.base_dir / "synthea.jar"
            if symlink_path.exists():
                symlink_path.unlink()
            symlink_path.symlink_to(jar_path.name)
            
            logger.info(f"Synthea downloaded successfully: {jar_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to download Synthea: {str(e)}")
            return False
    
    def create_configuration(self, config_overrides: Optional[dict] = None) -> bool:
        """
        Create Synthea configuration for surgical patient generation.
        
        Args:
            config_overrides: Custom configuration overrides
            
        Returns:
            True if configuration created successfully
        """
        try:
            # Default configuration optimized for surgical patients
            config = {
                "exporter.fhir.export": "true",
                "exporter.csv.export": "false",
                "exporter.text.export": "false",
                "exporter.ccda.export": "false",
                "exporter.json.export": "false",
                "exporter.hospital.fhir.export": "false",
                "exporter.practitioner.fhir.export": "false",
                
                # FHIR configuration
                "exporter.fhir.use_shr_extensions": "false",
                "exporter.fhir.use_us_core_ig": "true",
                "exporter.fhir.bulk_data": "false",
                
                # Population demographics
                "generate.demographics.socioeconomic.income.poverty": "0.11",
                "generate.demographics.socioeconomic.income.high": "0.20",
                "generate.demographics.socioeconomic.education.less_than_hs.percentage": "0.13",
                "generate.demographics.socioeconomic.education.hs_degree.percentage": "0.31",
                "generate.demographics.socioeconomic.education.some_college.percentage": "0.30",
                "generate.demographics.socioeconomic.education.bs_degree.percentage": "0.26",
                
                # Age distribution (focus on surgical age groups)
                "generate.demographics.default_file": "age_groups_surgical.csv",
                
                # Increase prevalence of conditions relevant to surgical risk
                "generate.prevalence.diabetes": "0.15",
                "generate.prevalence.hypertension": "0.25",
                "generate.prevalence.coronary_artery_disease": "0.08",
                "generate.prevalence.congestive_heart_failure": "0.05",
                "generate.prevalence.chronic_kidney_disease": "0.07",
                "generate.prevalence.copd": "0.06",
                
                # Output settings
                "exporter.baseDirectory": str(self.output_dir),
                "exporter.subfolders_by_id_substring": "false",
                "exporter.years_of_history": "10"
            }
            
            # Apply custom overrides
            if config_overrides:
                config.update(config_overrides)
            
            # Write configuration file
            config_file = self.config_dir / "synthea.properties"
            with open(config_file, 'w') as f:
                for key, value in config.items():
                    f.write(f"{key} = {value}\n")
            
            logger.info(f"Configuration created: {config_file}")
            
            # Create age distribution file for surgical patients
            self.create_surgical_age_distribution()
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to create configuration: {str(e)}")
            return False
    
    def create_surgical_age_distribution(self):
        """Create age distribution CSV optimized for surgical patients."""
        try:
            age_data = [
                "AGE,GENDER,POPULATION",
                "0,M,0.01",
                "0,F,0.01", 
                "1,M,0.01",
                "1,F,0.01",
                "5,M,0.02",
                "5,F,0.02",
                "10,M,0.02",
                "10,F,0.02",
                "15,M,0.03",
                "15,F,0.03",
                "20,M,0.04",
                "20,F,0.04",
                "25,M,0.05",
                "25,F,0.05",
                "30,M,0.06",
                "30,F,0.06",
                "35,M,0.07",
                "35,F,0.07",
                "40,M,0.08",
                "40,F,0.08",
                "45,M,0.09",
                "45,F,0.09",
                "50,M,0.10",
                "50,F,0.10",
                "55,M,0.11",
                "55,F,0.11",
                "60,M,0.12",
                "60,F,0.12",
                "65,M,0.13",
                "65,F,0.13",
                "70,M,0.12",
                "70,F,0.12",
                "75,M,0.10",
                "75,F,0.10",
                "80,M,0.08",
                "80,F,0.08",
                "85,M,0.05",
                "85,F,0.05",
                "90,M,0.02",
                "90,F,0.02",
                "95,M,0.01",
                "95,F,0.01"
            ]
            
            age_file = self.config_dir / "age_groups_surgical.csv"
            with open(age_file, 'w') as f:
                f.write('\n'.join(age_data))
            
            logger.info(f"Surgical age distribution created: {age_file}")
            
        except Exception as e:
            logger.error(f"Failed to create age distribution: {str(e)}")
    
    def generate_patients(self, population_size: int = 100, 
                         state: str = "Massachusetts",
                         city: Optional[str] = None) -> bool:
        """
        Generate synthetic patients using Synthea.
        
        Args:
            population_size: Number of patients to generate
            state: State for patient generation
            city: Optional city for patient generation
            
        Returns:
            True if generation successful
        """
        try:
            if not self.check_java_installation():
                logger.error("Java is required to run Synthea")
                return False
            
            jar_path = self.base_dir / "synthea.jar"
            if not jar_path.exists():
                logger.error("Synthea JAR not found. Run download_synthea() first.")
                return False
            
            # Build command
            cmd = [
                "java", "-jar", str(jar_path),
                "-p", str(population_size),
                "-s", "12345",  # Seed for reproducibility
                "--exporter.baseDirectory", str(self.output_dir)
            ]
            
            # Add configuration file if it exists
            config_file = self.config_dir / "synthea.properties"
            if config_file.exists():
                cmd.extend(["--exporter.properties_file", str(config_file)])
            
            # Add state
            cmd.append(state)
            
            # Add city if specified
            if city:
                cmd.append(city)
            
            logger.info(f"Generating {population_size} patients...")
            logger.info(f"Command: {' '.join(cmd)}")
            
            # Run Synthea
            result = subprocess.run(cmd, capture_output=True, text=True, 
                                  cwd=self.base_dir)
            
            if result.returncode == 0:
                logger.info("Patient generation completed successfully")
                logger.info(f"Output directory: {self.output_dir}")
                
                # List generated files
                fhir_files = list(self.output_dir.glob("*.json"))
                logger.info(f"Generated {len(fhir_files)} FHIR files")
                
                return True
            else:
                logger.error(f"Synthea execution failed: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to generate patients: {str(e)}")
            return False
    
    def validate_output(self) -> dict:
        """
        Validate generated Synthea output.
        
        Returns:
            Dictionary with validation results
        """
        try:
            results = {
                "fhir_files": 0,
                "total_patients": 0,
                "sample_file": None,
                "validation_errors": []
            }
            
            # Count FHIR files
            fhir_files = list(self.output_dir.glob("*.json"))
            results["fhir_files"] = len(fhir_files)
            
            if not fhir_files:
                results["validation_errors"].append("No FHIR files found")
                return results
            
            # Validate a sample file
            sample_file = fhir_files[0]
            results["sample_file"] = str(sample_file)
            
            try:
                with open(sample_file, 'r') as f:
                    data = json.load(f)
                
                if data.get("resourceType") != "Bundle":
                    results["validation_errors"].append("Sample file is not a FHIR Bundle")
                else:
                    # Count patients in sample file
                    entries = data.get("entry", [])
                    patient_count = sum(1 for entry in entries 
                                      if entry.get("resource", {}).get("resourceType") == "Patient")
                    results["total_patients"] = patient_count * len(fhir_files)
                    
            except json.JSONDecodeError:
                results["validation_errors"].append("Sample file is not valid JSON")
            
            return results
            
        except Exception as e:
            logger.error(f"Validation failed: {str(e)}")
            return {"validation_errors": [str(e)]}
    
    def cleanup_output(self):
        """Clean up generated output files."""
        try:
            if self.output_dir.exists():
                shutil.rmtree(self.output_dir)
                self.output_dir.mkdir()
                logger.info("Output directory cleaned")
        except Exception as e:
            logger.error(f"Failed to cleanup output: {str(e)}")


def main():
    """Main function for command-line usage."""
    parser = argparse.ArgumentParser(description="Synthea Setup and Data Generation")
    parser.add_argument("--base-dir", help="Base directory for Synthea installation")
    parser.add_argument("--download", action="store_true", help="Download Synthea")
    parser.add_argument("--version", default="3.2.0", help="Synthea version to download")
    parser.add_argument("--configure", action="store_true", help="Create configuration")
    parser.add_argument("--generate", type=int, metavar="N", help="Generate N patients")
    parser.add_argument("--state", default="Massachusetts", help="State for generation")
    parser.add_argument("--city", help="City for generation")
    parser.add_argument("--validate", action="store_true", help="Validate output")
    parser.add_argument("--cleanup", action="store_true", help="Clean up output")
    
    args = parser.parse_args()
    
    # Initialize setup
    setup = SyntheaSetup(args.base_dir)
    
    # Execute requested actions
    if args.download:
        if not setup.download_synthea(args.version):
            sys.exit(1)
    
    if args.configure:
        if not setup.create_configuration():
            sys.exit(1)
    
    if args.generate:
        if not setup.generate_patients(args.generate, args.state, args.city):
            sys.exit(1)
    
    if args.validate:
        results = setup.validate_output()
        print(json.dumps(results, indent=2))
    
    if args.cleanup:
        setup.cleanup_output()
    
    # If no specific action requested, show help
    if not any([args.download, args.configure, args.generate, args.validate, args.cleanup]):
        parser.print_help()


if __name__ == "__main__":
    main()

