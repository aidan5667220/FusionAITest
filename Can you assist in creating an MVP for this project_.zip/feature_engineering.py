"""
Feature Engineering Module for Surgical Risk Assessment
Converts raw patient data into structured features for ML model training and inference.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Any, Tuple
import json
from sklearn.preprocessing import StandardScaler, LabelEncoder
import pickle

class SurgicalRiskFeatureEngineer:
    def __init__(self):
        """Initialize the feature engineering pipeline."""
        self.feature_columns = []
        self.scalers = {}
        self.encoders = {}
        self.is_fitted = False
        
        # Define the complete feature set (~60 features as mentioned in design doc)
        self.numeric_features = [
            'age', 'bmi', 'height_cm', 'weight_kg',
            'creatinine', 'hemoglobin', 'sodium', 'potassium', 'alt', 'inr',
            'sbp', 'dbp', 'heart_rate', 'spo2', 'temperature',
            'procedure_duration_min', 'num_conditions', 'num_medications'
        ]
        
        self.categorical_features = [
            'sex', 'cpt_invasiveness_tier', 'asa_class'
        ]
        
        self.boolean_features = [
            'emergency_surgery', 'bmi_ge50', 'bmi_ge40', 'bmi_ge35',
            'age_ge80', 'age_ge70', 'creatinine_ge2', 'hemoglobin_lt10',
            'inr_ge2', 'recent_mi', 'recent_cva', 'heart_failure',
            'severe_as', 'lvef_lt40', 'copd', 'diabetes', 'hypertension',
            'on_warfarin', 'on_insulin', 'on_steroids', 'high_risk_surgery',
            'asa_ge4'
        ]
        
        # Additional engineered features
        self.derived_features = [
            'pulse_pressure', 'map', 'bmi_category', 'age_category',
            'kidney_function_category', 'anemia_severity', 'risk_factor_count'
        ]

    def extract_raw_features(self, patient_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract raw features from patient data structure."""
        features = {}
        
        # Demographics
        features['age'] = patient_data['age']
        features['sex'] = patient_data['sex']
        features['height_cm'] = patient_data['height_cm']
        features['weight_kg'] = patient_data['weight_kg']
        features['bmi'] = patient_data['bmi']
        
        # Lab values
        for lab, value in patient_data['labs'].items():
            features[lab] = value
        
        # Vital signs
        for vital, value in patient_data['vitals'].items():
            features[vital] = value
        
        # Surgical details
        features['cpt_invasiveness_tier'] = patient_data['surgical_details']['cpt_invasiveness_tier']
        features['asa_class'] = patient_data['surgical_details']['asa_class']
        features['procedure_duration_min'] = patient_data['surgical_details']['procedure_duration_min']
        features['emergency_surgery'] = patient_data['surgical_details']['emergency_case']
        
        # Medical history counts
        features['num_conditions'] = len(patient_data['medical_history']['conditions'])
        features['num_medications'] = len(patient_data['medical_history']['medications'])
        
        # Engineered boolean features
        for feature, value in patient_data['engineered_features'].items():
            features[feature] = value
        
        return features

    def create_derived_features(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """Create additional derived features."""
        derived = {}
        
        # Cardiovascular derived features
        derived['pulse_pressure'] = features['sbp'] - features['dbp']
        derived['map'] = features['dbp'] + (derived['pulse_pressure'] / 3)  # Mean arterial pressure
        
        # BMI categories
        bmi = features['bmi']
        if bmi < 18.5:
            derived['bmi_category'] = 'underweight'
        elif bmi < 25:
            derived['bmi_category'] = 'normal'
        elif bmi < 30:
            derived['bmi_category'] = 'overweight'
        elif bmi < 35:
            derived['bmi_category'] = 'obese_1'
        elif bmi < 40:
            derived['bmi_category'] = 'obese_2'
        else:
            derived['bmi_category'] = 'obese_3'
        
        # Age categories
        age = features['age']
        if age < 40:
            derived['age_category'] = 'young'
        elif age < 65:
            derived['age_category'] = 'middle'
        elif age < 80:
            derived['age_category'] = 'elderly'
        else:
            derived['age_category'] = 'very_elderly'
        
        # Kidney function categories (based on creatinine)
        creatinine = features['creatinine']
        if creatinine < 1.2:
            derived['kidney_function_category'] = 'normal'
        elif creatinine < 2.0:
            derived['kidney_function_category'] = 'mild_impairment'
        elif creatinine < 3.0:
            derived['kidney_function_category'] = 'moderate_impairment'
        else:
            derived['kidney_function_category'] = 'severe_impairment'
        
        # Anemia severity (based on hemoglobin)
        hgb = features['hemoglobin']
        sex = features['sex']
        if sex == 'M':
            if hgb >= 13.5:
                derived['anemia_severity'] = 'none'
            elif hgb >= 11.0:
                derived['anemia_severity'] = 'mild'
            elif hgb >= 8.0:
                derived['anemia_severity'] = 'moderate'
            else:
                derived['anemia_severity'] = 'severe'
        else:  # Female
            if hgb >= 12.0:
                derived['anemia_severity'] = 'none'
            elif hgb >= 10.0:
                derived['anemia_severity'] = 'mild'
            elif hgb >= 8.0:
                derived['anemia_severity'] = 'moderate'
            else:
                derived['anemia_severity'] = 'severe'
        
        # Risk factor count (sum of boolean risk factors)
        risk_factors = [
            'bmi_ge40', 'age_ge80', 'creatinine_ge2', 'hemoglobin_lt10',
            'recent_mi', 'recent_cva', 'heart_failure', 'severe_as',
            'emergency_surgery', 'asa_ge4'
        ]
        derived['risk_factor_count'] = sum(1 for rf in risk_factors if features.get(rf, False))
        
        return derived

    def prepare_features_for_ml(self, patient_data: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare complete feature set for ML model."""
        # Extract raw features
        features = self.extract_raw_features(patient_data)
        
        # Add derived features
        derived = self.create_derived_features(features)
        features.update(derived)
        
        return features

    def create_feature_matrix(self, patients_data: List[Dict[str, Any]]) -> Tuple[pd.DataFrame, np.ndarray]:
        """Create feature matrix and target vector from patient data."""
        feature_rows = []
        targets = []
        
        for patient in patients_data:
            features = self.prepare_features_for_ml(patient)
            feature_rows.append(features)
            targets.append(patient['outcome_30day_complication'])
        
        # Convert to DataFrame
        df = pd.DataFrame(feature_rows)
        
        # Handle categorical variables
        categorical_columns = []
        for col in df.columns:
            if df[col].dtype == 'object' or col in self.categorical_features:
                categorical_columns.append(col)
        
        # One-hot encode categorical variables
        df_encoded = pd.get_dummies(df, columns=categorical_columns, prefix=categorical_columns)
        
        # Convert boolean columns to int
        for col in df_encoded.columns:
            if df_encoded[col].dtype == 'bool':
                df_encoded[col] = df_encoded[col].astype(int)
        
        # Store feature columns for later use
        self.feature_columns = df_encoded.columns.tolist()
        
        return df_encoded, np.array(targets)

    def fit_scalers(self, X: pd.DataFrame):
        """Fit scalers on the training data."""
        # Identify numeric columns that need scaling
        numeric_cols = []
        for col in X.columns:
            if col in self.numeric_features or 'pulse_pressure' in col or 'map' in col or 'risk_factor_count' in col:
                if X[col].dtype in ['int64', 'float64']:
                    numeric_cols.append(col)
        
        # Fit scalers
        for col in numeric_cols:
            scaler = StandardScaler()
            scaler.fit(X[[col]])
            self.scalers[col] = scaler
        
        self.is_fitted = True

    def transform_features(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transform features using fitted scalers."""
        if not self.is_fitted:
            raise ValueError("Scalers must be fitted before transformation")
        
        X_transformed = X.copy()
        
        # Apply scaling to numeric features
        for col, scaler in self.scalers.items():
            if col in X_transformed.columns:
                X_transformed[col] = scaler.transform(X_transformed[[col]]).flatten()
        
        return X_transformed

    def fit_transform(self, patients_data: List[Dict[str, Any]]) -> Tuple[pd.DataFrame, np.ndarray]:
        """Fit scalers and transform data in one step."""
        X, y = self.create_feature_matrix(patients_data)
        self.fit_scalers(X)
        X_transformed = self.transform_features(X)
        return X_transformed, y

    def transform_single_patient(self, patient_data: Dict[str, Any]) -> pd.DataFrame:
        """Transform a single patient's data for prediction."""
        features = self.prepare_features_for_ml(patient_data)
        
        # Convert to DataFrame with single row
        df = pd.DataFrame([features])
        
        # Handle categorical variables (same as training)
        categorical_columns = []
        for col in df.columns:
            if df[col].dtype == 'object' or col in self.categorical_features:
                categorical_columns.append(col)
        
        df_encoded = pd.get_dummies(df, columns=categorical_columns, prefix=categorical_columns)
        
        # Convert boolean columns to int
        for col in df_encoded.columns:
            if df_encoded[col].dtype == 'bool':
                df_encoded[col] = df_encoded[col].astype(int)
        
        # Ensure all training columns are present
        for col in self.feature_columns:
            if col not in df_encoded.columns:
                df_encoded[col] = 0
        
        # Reorder columns to match training
        df_encoded = df_encoded[self.feature_columns]
        
        # Apply scaling
        if self.is_fitted:
            df_encoded = self.transform_features(df_encoded)
        
        return df_encoded

    def get_feature_importance_names(self) -> List[str]:
        """Get human-readable feature names for importance analysis."""
        feature_names = []
        for col in self.feature_columns:
            # Clean up feature names for readability
            if col.startswith('sex_'):
                feature_names.append(f"Sex: {col.split('_')[1]}")
            elif col.startswith('bmi_category_'):
                feature_names.append(f"BMI Category: {col.split('_', 2)[2]}")
            elif col.startswith('age_category_'):
                feature_names.append(f"Age Category: {col.split('_', 2)[2]}")
            elif col.startswith('kidney_function_category_'):
                feature_names.append(f"Kidney Function: {col.split('_', 3)[3]}")
            elif col.startswith('anemia_severity_'):
                feature_names.append(f"Anemia Severity: {col.split('_', 2)[2]}")
            else:
                # Convert snake_case to readable format
                readable = col.replace('_', ' ').title()
                feature_names.append(readable)
        
        return feature_names

    def save_feature_engineer(self, filepath: str):
        """Save the fitted feature engineer to disk."""
        save_data = {
            'feature_columns': self.feature_columns,
            'scalers': self.scalers,
            'encoders': self.encoders,
            'is_fitted': self.is_fitted,
            'numeric_features': self.numeric_features,
            'categorical_features': self.categorical_features,
            'boolean_features': self.boolean_features,
            'derived_features': self.derived_features
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(save_data, f)

    def load_feature_engineer(self, filepath: str):
        """Load a fitted feature engineer from disk."""
        with open(filepath, 'rb') as f:
            save_data = pickle.load(f)
        
        self.feature_columns = save_data['feature_columns']
        self.scalers = save_data['scalers']
        self.encoders = save_data['encoders']
        self.is_fitted = save_data['is_fitted']
        self.numeric_features = save_data['numeric_features']
        self.categorical_features = save_data['categorical_features']
        self.boolean_features = save_data['boolean_features']
        self.derived_features = save_data['derived_features']

def analyze_feature_distribution(X: pd.DataFrame, y: np.ndarray) -> pd.DataFrame:
    """Analyze feature distributions and correlations with outcome."""
    analysis = []
    
    for col in X.columns:
        if X[col].dtype in ['int64', 'float64']:
            # Numeric feature analysis
            overall_mean = X[col].mean()
            overall_std = X[col].std()
            
            positive_mean = X[y == 1][col].mean() if sum(y == 1) > 0 else 0
            negative_mean = X[y == 0][col].mean() if sum(y == 0) > 0 else 0
            
            correlation = np.corrcoef(X[col], y)[0, 1] if not X[col].isna().all() else 0
            
            analysis.append({
                'feature': col,
                'type': 'numeric',
                'overall_mean': overall_mean,
                'overall_std': overall_std,
                'positive_outcome_mean': positive_mean,
                'negative_outcome_mean': negative_mean,
                'correlation_with_outcome': correlation,
                'missing_rate': X[col].isna().mean()
            })
        else:
            # Categorical/binary feature analysis
            value_counts = X[col].value_counts()
            positive_rate = X[y == 1][col].value_counts() / sum(y == 1) if sum(y == 1) > 0 else pd.Series()
            
            analysis.append({
                'feature': col,
                'type': 'categorical',
                'unique_values': len(value_counts),
                'most_common_value': value_counts.index[0] if len(value_counts) > 0 else None,
                'most_common_frequency': value_counts.iloc[0] / len(X) if len(value_counts) > 0 else 0,
                'missing_rate': X[col].isna().mean()
            })
    
    return pd.DataFrame(analysis)

if __name__ == "__main__":
    # Test the feature engineering pipeline
    print("Testing Feature Engineering Pipeline...")
    
    # Load test data
    with open('/home/ubuntu/surgical-risk-mvp/data/synthetic/test_patients.json', 'r') as f:
        test_patients = json.load(f)
    
    # Initialize feature engineer
    fe = SurgicalRiskFeatureEngineer()
    
    # Create feature matrix
    X, y = fe.fit_transform(test_patients)
    
    print(f"Feature matrix shape: {X.shape}")
    print(f"Target vector shape: {y.shape}")
    print(f"Positive outcome rate: {y.mean():.3f}")
    print(f"Number of features: {len(fe.feature_columns)}")
    
    # Analyze features
    analysis = analyze_feature_distribution(X, y)
    print("\nTop 10 features by correlation with outcome:")
    numeric_analysis = analysis[analysis['type'] == 'numeric'].sort_values('correlation_with_outcome', key=abs, ascending=False)
    print(numeric_analysis[['feature', 'correlation_with_outcome']].head(10))
    
    # Save feature engineer
    fe.save_feature_engineer('/home/ubuntu/surgical-risk-mvp/models/feature_engineer.pkl')
    print("\nFeature engineer saved successfully!")
    
    # Test single patient transformation
    test_patient = test_patients[0]
    single_features = fe.transform_single_patient(test_patient)
    print(f"\nSingle patient feature shape: {single_features.shape}")
    print("Feature engineering pipeline test completed successfully!")

