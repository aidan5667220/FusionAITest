"""
Synthetic Medical Data Generator for Surgical Risk Assessment MVP
Generates realistic synthetic patient data matching the features described in the design document.
"""

import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
import json
from typing import Dict, List, Any

class SyntheticMedicalDataGenerator:
    def __init__(self, seed: int = 42):
        """Initialize the synthetic data generator with a random seed for reproducibility."""
        np.random.seed(seed)
        random.seed(seed)
        
        # Define reference ranges and distributions
        self.age_distribution = {'mean': 65, 'std': 15, 'min': 18, 'max': 95}
        self.bmi_distribution = {'mean': 28, 'std': 6, 'min': 16, 'max': 60}
        
        # Lab reference ranges (normal values)
        self.lab_ranges = {
            'creatinine': {'mean': 1.0, 'std': 0.3, 'min': 0.5, 'max': 3.0, 'unit': 'mg/dL'},
            'hemoglobin': {'mean': 13.5, 'std': 2.0, 'min': 8.0, 'max': 18.0, 'unit': 'g/dL'},
            'sodium': {'mean': 140, 'std': 3, 'min': 130, 'max': 150, 'unit': 'mEq/L'},
            'potassium': {'mean': 4.0, 'std': 0.5, 'min': 3.0, 'max': 5.5, 'unit': 'mEq/L'},
            'alt': {'mean': 25, 'std': 15, 'min': 5, 'max': 100, 'unit': 'U/L'},
            'inr': {'mean': 1.1, 'std': 0.2, 'min': 0.8, 'max': 3.0, 'unit': 'ratio'}
        }
        
        # Vital signs ranges
        self.vital_ranges = {
            'sbp': {'mean': 130, 'std': 20, 'min': 90, 'max': 200, 'unit': 'mmHg'},
            'dbp': {'mean': 80, 'std': 15, 'min': 50, 'max': 120, 'unit': 'mmHg'},
            'heart_rate': {'mean': 75, 'std': 15, 'min': 50, 'max': 120, 'unit': 'bpm'},
            'spo2': {'mean': 98, 'std': 2, 'min': 88, 'max': 100, 'unit': '%'},
            'temperature': {'mean': 98.6, 'std': 1.0, 'min': 96.0, 'max': 102.0, 'unit': 'F'}
        }
        
        # CPT invasiveness tiers (simplified)
        self.cpt_tiers = {
            1: {'name': 'Minor', 'examples': ['Skin biopsy', 'Cataract surgery'], 'base_risk': 0.02},
            2: {'name': 'Intermediate', 'examples': ['Appendectomy', 'Hernia repair'], 'base_risk': 0.05},
            3: {'name': 'Major', 'examples': ['Cholecystectomy', 'Hip replacement'], 'base_risk': 0.10},
            4: {'name': 'Complex', 'examples': ['Cardiac surgery', 'Liver resection'], 'base_risk': 0.20},
            5: {'name': 'High-risk', 'examples': ['Transplant', 'Major vascular'], 'base_risk': 0.35}
        }
        
        # ASA Physical Status Classification
        self.asa_classes = {
            1: {'description': 'Normal healthy patient', 'risk_multiplier': 1.0},
            2: {'description': 'Mild systemic disease', 'risk_multiplier': 1.2},
            3: {'description': 'Severe systemic disease', 'risk_multiplier': 1.8},
            4: {'description': 'Severe disease, constant threat to life', 'risk_multiplier': 3.0},
            5: {'description': 'Moribund patient', 'risk_multiplier': 5.0}
        }
        
        # Common medical conditions
        self.conditions = [
            'Hypertension', 'Diabetes mellitus type 2', 'Coronary artery disease',
            'Chronic kidney disease', 'COPD', 'Atrial fibrillation', 'Heart failure',
            'Obesity', 'Hyperlipidemia', 'Osteoarthritis', 'Depression', 'Anxiety',
            'Hypothyroidism', 'Gastroesophageal reflux', 'Chronic pain'
        ]
        
        # Medications
        self.medications = [
            'Lisinopril', 'Metformin', 'Atorvastatin', 'Amlodipine', 'Metoprolol',
            'Omeprazole', 'Levothyroxine', 'Aspirin', 'Warfarin', 'Insulin',
            'Furosemide', 'Gabapentin', 'Sertraline', 'Albuterol', 'Prednisone'
        ]

    def generate_patient_demographics(self) -> Dict[str, Any]:
        """Generate basic patient demographics."""
        age = max(self.age_distribution['min'], 
                 min(self.age_distribution['max'],
                     int(np.random.normal(self.age_distribution['mean'], 
                                        self.age_distribution['std']))))
        
        sex = random.choice(['M', 'F'])
        
        # Height and weight for BMI calculation
        if sex == 'M':
            height_cm = np.random.normal(175, 8)  # Male average height
        else:
            height_cm = np.random.normal(162, 7)  # Female average height
            
        height_m = height_cm / 100
        
        # Generate BMI and calculate weight
        bmi = max(self.bmi_distribution['min'],
                 min(self.bmi_distribution['max'],
                     np.random.normal(self.bmi_distribution['mean'],
                                    self.bmi_distribution['std'])))
        
        weight_kg = bmi * (height_m ** 2)
        
        return {
            'patient_id': f"PAT_{random.randint(100000, 999999)}",
            'age': age,
            'sex': sex,
            'height_cm': round(height_cm, 1),
            'weight_kg': round(weight_kg, 1),
            'bmi': round(bmi, 1)
        }

    def generate_lab_values(self, risk_factor: float = 1.0) -> Dict[str, float]:
        """Generate lab values with optional risk adjustment."""
        labs = {}
        
        for lab, params in self.lab_ranges.items():
            # Adjust distribution based on risk factor
            if risk_factor > 1.5:  # High-risk patients have more abnormal labs
                if lab == 'creatinine':
                    value = np.random.normal(params['mean'] * 1.3, params['std'] * 1.2)
                elif lab == 'hemoglobin':
                    value = np.random.normal(params['mean'] * 0.9, params['std'] * 1.1)
                elif lab == 'inr':
                    value = np.random.normal(params['mean'] * 1.2, params['std'] * 1.3)
                else:
                    value = np.random.normal(params['mean'], params['std'] * 1.2)
            else:
                value = np.random.normal(params['mean'], params['std'])
            
            # Clamp to reasonable ranges
            value = max(params['min'], min(params['max'], value))
            labs[lab] = round(value, 2)
            
        return labs

    def generate_vital_signs(self, risk_factor: float = 1.0) -> Dict[str, float]:
        """Generate vital signs with optional risk adjustment."""
        vitals = {}
        
        for vital, params in self.vital_ranges.items():
            if risk_factor > 1.5:  # High-risk patients have more abnormal vitals
                if vital == 'sbp':
                    value = np.random.normal(params['mean'] * 1.15, params['std'] * 1.2)
                elif vital == 'heart_rate':
                    value = np.random.normal(params['mean'] * 1.1, params['std'] * 1.2)
                elif vital == 'spo2':
                    value = np.random.normal(params['mean'] * 0.98, params['std'] * 1.5)
                else:
                    value = np.random.normal(params['mean'], params['std'] * 1.1)
            else:
                value = np.random.normal(params['mean'], params['std'])
            
            # Clamp to reasonable ranges
            value = max(params['min'], min(params['max'], value))
            
            # Special handling for DBP (should be related to SBP)
            if vital == 'dbp' and 'sbp' in vitals:
                # DBP should be roughly 60-80% of SBP
                dbp_ratio = np.random.normal(0.7, 0.1)
                value = vitals['sbp'] * dbp_ratio
                value = max(50, min(120, value))
            
            vitals[vital] = round(value, 1)
            
        return vitals

    def generate_surgical_details(self) -> Dict[str, Any]:
        """Generate surgical procedure details."""
        cpt_tier = random.choices(
            list(self.cpt_tiers.keys()),
            weights=[30, 25, 20, 15, 10],  # More common procedures are lower tier
            k=1
        )[0]
        
        asa_class = random.choices(
            list(self.asa_classes.keys()),
            weights=[10, 30, 35, 20, 5],  # ASA 2-3 most common
            k=1
        )[0]
        
        procedure_name = random.choice(self.cpt_tiers[cpt_tier]['examples'])
        
        return {
            'cpt_invasiveness_tier': cpt_tier,
            'asa_class': asa_class,
            'procedure_name': procedure_name,
            'procedure_duration_min': random.randint(30, 480),  # 30 min to 8 hours
            'emergency_case': random.choice([True, False]) if random.random() < 0.15 else False
        }

    def generate_medical_history(self, age: int, risk_factor: float) -> Dict[str, Any]:
        """Generate medical history and conditions."""
        # Number of conditions increases with age and risk
        base_conditions = max(0, int(np.random.poisson(age / 20 + risk_factor)))
        num_conditions = min(len(self.conditions), base_conditions)
        
        patient_conditions = random.sample(self.conditions, num_conditions)
        
        # Number of medications roughly correlates with conditions
        num_medications = max(0, int(np.random.poisson(len(patient_conditions) * 1.2)))
        num_medications = min(len(self.medications), num_medications)
        patient_medications = random.sample(self.medications, num_medications)
        
        return {
            'conditions': patient_conditions,
            'medications': patient_medications,
            'allergies': random.sample(['Penicillin', 'Sulfa', 'Latex', 'Iodine'], 
                                     random.randint(0, 2))
        }

    def generate_engineered_features(self, patient_data: Dict[str, Any]) -> Dict[str, bool]:
        """Generate engineered boolean feature flags."""
        features = {}
        
        # BMI-based features
        features['bmi_ge50'] = patient_data['bmi'] >= 50
        features['bmi_ge40'] = patient_data['bmi'] >= 40
        features['bmi_ge35'] = patient_data['bmi'] >= 35
        
        # Age-based features
        features['age_ge80'] = patient_data['age'] >= 80
        features['age_ge70'] = patient_data['age'] >= 70
        
        # Lab-based features
        labs = patient_data['labs']
        features['creatinine_ge2'] = labs['creatinine'] >= 2.0
        features['hemoglobin_lt10'] = labs['hemoglobin'] < 10.0
        features['inr_ge2'] = labs['inr'] >= 2.0
        
        # Condition-based features (probabilistic based on conditions)
        conditions = patient_data['medical_history']['conditions']
        features['recent_mi'] = 'Coronary artery disease' in conditions and random.random() < 0.3
        features['recent_cva'] = random.random() < 0.05  # 5% chance
        features['heart_failure'] = 'Heart failure' in conditions
        features['severe_as'] = random.random() < 0.03  # 3% chance of severe aortic stenosis
        features['lvef_lt40'] = features['heart_failure'] and random.random() < 0.4
        features['copd'] = 'COPD' in conditions
        features['diabetes'] = 'Diabetes mellitus type 2' in conditions
        features['hypertension'] = 'Hypertension' in conditions
        
        # Medication-based features
        medications = patient_data['medical_history']['medications']
        features['on_warfarin'] = 'Warfarin' in medications
        features['on_insulin'] = 'Insulin' in medications
        features['on_steroids'] = 'Prednisone' in medications
        
        # Surgical features
        features['emergency_surgery'] = patient_data['surgical_details']['emergency_case']
        features['high_risk_surgery'] = patient_data['surgical_details']['cpt_invasiveness_tier'] >= 4
        features['asa_ge4'] = patient_data['surgical_details']['asa_class'] >= 4
        
        return features

    def calculate_true_risk(self, patient_data: Dict[str, Any]) -> float:
        """Calculate the 'true' risk for synthetic outcome generation."""
        # Start with base risk from procedure
        base_risk = self.cpt_tiers[patient_data['surgical_details']['cpt_invasiveness_tier']]['base_risk']
        
        # Apply ASA class multiplier
        asa_multiplier = self.asa_classes[patient_data['surgical_details']['asa_class']]['risk_multiplier']
        risk = base_risk * asa_multiplier
        
        # Age adjustments
        if patient_data['age'] >= 80:
            risk *= 2.0
        elif patient_data['age'] >= 70:
            risk *= 1.5
        
        # Condition adjustments
        engineered = patient_data['engineered_features']
        if engineered['recent_mi']:
            risk *= 2.5
        if engineered['recent_cva']:
            risk *= 2.0
        if engineered['heart_failure']:
            risk *= 1.8
        if engineered['lvef_lt40']:
            risk *= 2.2
        if engineered['severe_as']:
            risk *= 3.0
        if engineered['bmi_ge50']:
            risk *= 1.8
        if engineered['creatinine_ge2']:
            risk *= 1.6
        if engineered['hemoglobin_lt10']:
            risk *= 1.4
        if engineered['emergency_surgery']:
            risk *= 1.5
        
        # Cap at reasonable maximum
        return min(0.8, risk)

    def generate_clinical_notes(self, patient_data: Dict[str, Any]) -> str:
        """Generate synthetic clinical notes."""
        notes = []
        
        # History of Present Illness
        procedure = patient_data['surgical_details']['procedure_name']
        notes.append(f"Patient is a {patient_data['age']}-year-old {patient_data['sex']} scheduled for {procedure}.")
        
        if patient_data['surgical_details']['emergency_case']:
            notes.append("This is an emergency procedure.")
        
        # Past Medical History
        if patient_data['medical_history']['conditions']:
            conditions_str = ", ".join(patient_data['medical_history']['conditions'])
            notes.append(f"Past medical history significant for {conditions_str}.")
        
        # Medications
        if patient_data['medical_history']['medications']:
            meds_str = ", ".join(patient_data['medical_history']['medications'][:5])  # Limit for readability
            notes.append(f"Current medications include {meds_str}.")
        
        # Physical Exam
        vitals = patient_data['vitals']
        notes.append(f"Vital signs: BP {vitals['sbp']}/{vitals['dbp']}, HR {vitals['heart_rate']}, "
                    f"SpO2 {vitals['spo2']}%, Temp {vitals['temperature']}°F.")
        
        notes.append(f"BMI {patient_data['bmi']}.")
        
        # Assessment
        asa = patient_data['surgical_details']['asa_class']
        notes.append(f"ASA Physical Status Class {asa}.")
        
        if patient_data['engineered_features']['bmi_ge40']:
            notes.append("Patient has severe obesity.")
        
        if patient_data['engineered_features']['creatinine_ge2']:
            notes.append("Chronic kidney disease with elevated creatinine.")
        
        if patient_data['engineered_features']['heart_failure']:
            notes.append("History of congestive heart failure.")
        
        return " ".join(notes)

    def generate_single_patient(self, risk_bias: str = 'random') -> Dict[str, Any]:
        """Generate a complete synthetic patient record."""
        # Determine risk factor for this patient
        if risk_bias == 'high':
            risk_factor = np.random.uniform(2.0, 3.0)
        elif risk_bias == 'low':
            risk_factor = np.random.uniform(0.5, 1.0)
        else:  # random
            risk_factor = np.random.uniform(0.8, 2.5)
        
        # Generate all components
        demographics = self.generate_patient_demographics()
        labs = self.generate_lab_values(risk_factor)
        vitals = self.generate_vital_signs(risk_factor)
        surgical = self.generate_surgical_details()
        medical_history = self.generate_medical_history(demographics['age'], risk_factor)
        
        # Combine all data
        patient_data = {
            **demographics,
            'labs': labs,
            'vitals': vitals,
            'surgical_details': surgical,
            'medical_history': medical_history
        }
        
        # Generate engineered features
        engineered_features = self.generate_engineered_features(patient_data)
        patient_data['engineered_features'] = engineered_features
        
        # Calculate true risk and outcome
        true_risk = self.calculate_true_risk(patient_data)
        patient_data['true_risk_probability'] = true_risk
        patient_data['true_risk_score'] = int(true_risk * 100)
        
        # Generate outcome (30-day major complication)
        patient_data['outcome_30day_complication'] = random.random() < true_risk
        
        # Generate clinical notes
        patient_data['clinical_notes'] = self.generate_clinical_notes(patient_data)
        
        # Add timestamp
        patient_data['created_at'] = datetime.now().isoformat()
        
        return patient_data

    def generate_dataset(self, n_patients: int = 1000, 
                        high_risk_ratio: float = 0.3,
                        low_risk_ratio: float = 0.3) -> List[Dict[str, Any]]:
        """Generate a complete dataset of synthetic patients."""
        patients = []
        
        # Calculate how many of each risk type
        n_high = int(n_patients * high_risk_ratio)
        n_low = int(n_patients * low_risk_ratio)
        n_random = n_patients - n_high - n_low
        
        print(f"Generating {n_patients} synthetic patients:")
        print(f"  - {n_high} high-risk patients")
        print(f"  - {n_low} low-risk patients")
        print(f"  - {n_random} random-risk patients")
        
        # Generate high-risk patients
        for i in range(n_high):
            patients.append(self.generate_single_patient('high'))
            if (i + 1) % 100 == 0:
                print(f"  Generated {i + 1}/{n_high} high-risk patients")
        
        # Generate low-risk patients
        for i in range(n_low):
            patients.append(self.generate_single_patient('low'))
            if (i + 1) % 100 == 0:
                print(f"  Generated {i + 1}/{n_low} low-risk patients")
        
        # Generate random patients
        for i in range(n_random):
            patients.append(self.generate_single_patient('random'))
            if (i + 1) % 100 == 0:
                print(f"  Generated {i + 1}/{n_random} random patients")
        
        # Shuffle the dataset
        random.shuffle(patients)
        
        return patients

if __name__ == "__main__":
    # Example usage
    generator = SyntheticMedicalDataGenerator()
    
    # Generate a small test dataset
    test_patients = generator.generate_dataset(n_patients=100)
    
    # Save to JSON
    with open('/home/ubuntu/surgical-risk-mvp/data/synthetic/test_patients.json', 'w') as f:
        json.dump(test_patients, f, indent=2)
    
    print(f"Generated {len(test_patients)} test patients")
    print(f"Sample patient keys: {list(test_patients[0].keys())}")

